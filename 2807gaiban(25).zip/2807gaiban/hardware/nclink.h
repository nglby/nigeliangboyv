#ifndef NCLINK_H
#define NCLINK_H

#include "main.h"
#include "pid.h"

/* Nameless Innovation NC-Link protocol used by the supplied MaplePilot code.
 * FC -> PC: FF FC, PC -> FC: FC FF, tail A1 A2, XOR checksum. */

void NCLink_Init(UART_HandleTypeDef *huart);
void NCLink_RxByteIRQ(uint8_t data);

/* Call from the main loop. PID writes are accepted only when allow_pid_write
 * is non-zero. This keeps parameter changes out of an actual flight. */
void NCLink_Service(uint32_t now_ms,
                    PID_t *roll_rate, PID_t *pitch_rate, PID_t *yaw_rate,
                    PID_t *roll_angle, PID_t *pitch_angle,
                    float roll_deg, float pitch_deg, float yaw_deg,
                    float roll_rate_dps, float pitch_rate_dps,
                    float yaw_rate_dps, uint8_t armed,
                    uint8_t allow_pid_write);

#endif

#include "yaokong.h"
#include <string.h>

/* Direct STM32F407 adaptation of fly/fc_driver/driver/drv_ppm.c and rc.c. */
#define PPM_CHANNEL_COUNT       8U
#define PPM_GLITCH_MIN_US      600U
#define PPM_SYNC_MIN_US       2500U
#define PPM_PWM_REJECT_US    12500U
#define PPM_CHANNEL_MIN_US     800U
#define PPM_CHANNEL_MAX_US    2200U

#define RC_MIN_US             1000U
#define RC_MIDDLE_US          1500U
#define RC_MAX_US             2000U
#define RC_DEADBAND_US         100U
#define RC_SCALE_US            450.0f
#define RC_YAW_MAX             YAOKONG_MAX_YAW_RATE_DPS
#define RC_GESTURE_SCALE         0.75f
#define RC_UNLOCK_FRAMES       100U
#define RC_LOCK_FRAMES          50U

static volatile YaoKong_State_t rc_state;
static volatile uint16_t ppm_buffer[PPM_CHANNEL_COUNT];
static volatile uint8_t ppm_ready;
static volatile uint8_t ppm_sample_count;
static volatile uint32_t ppm_last_edge_cycles;
static volatile uint8_t ppm_have_edge;
static volatile uint32_t ppm_work_count;
static volatile uint32_t ppm_miss_count;
static uint32_t last_processed_frame;
static uint16_t unlock_confirm_count;
static uint16_t lock_confirm_count;
static uint16_t failsafe_recovery_count;
static uint32_t failsafe_recovery_last_frame_ms;

static float Remote_DataRemap(uint16_t pulse_us, float max_down,
                              float max_up, uint8_t reverse)
{
    float value = 0.0f;

    if (pulse_us <= RC_MIDDLE_US - RC_DEADBAND_US / 2U) {
        value = (float)(RC_MIDDLE_US - RC_DEADBAND_US / 2U - pulse_us)
              * max_down / RC_SCALE_US;
    } else if (pulse_us >= RC_MIDDLE_US + RC_DEADBAND_US / 2U) {
        value = (float)((int32_t)(RC_MIDDLE_US + RC_DEADBAND_US / 2U)
              - (int32_t)pulse_us) * max_up / RC_SCALE_US;
    }

    if (reverse) value = -value;
    return value;
}

void YaoKong_Init(void)
{
    uint8_t i;
    memset((void *)&rc_state, 0, sizeof(rc_state));
    for (i = 0U; i < YAOKONG_CHANNEL_COUNT; i++) rc_state.channel[i] = RC_MIDDLE_US;
    rc_state.channel[YAOKONG_CH_THROTTLE] = RC_MIN_US;
    rc_state.throttle_us = RC_MIN_US;
    ppm_ready = 0U;
    ppm_sample_count = 0U;
    ppm_last_edge_cycles = 0U;
    ppm_have_edge = 0U;
    ppm_work_count = 0U;
    ppm_miss_count = 0U;
    last_processed_frame = 0U;
    unlock_confirm_count = 0U;
    lock_confirm_count = 0U;
    failsafe_recovery_count = 0U;
    failsafe_recovery_last_frame_ms = 0U;

    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0U;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

void YaoKong_PPM_IRQHandler(void)
{
    uint32_t now_cycles = DWT->CYCCNT;
    uint32_t interval_us;
    uint32_t denominator;
    uint8_t i;

    if (!ppm_have_edge) {
        ppm_last_edge_cycles = now_cycles;
        ppm_have_edge = 1U;
        return;
    }

    interval_us = (now_cycles - ppm_last_edge_cycles)
                / (SystemCoreClock / 1000000U);

    /* A short EMI edge is not a real PPM edge, so it must not become the new
     * timing origin.  Updating ppm_last_edge_cycles before this check turns a
     * real 1600 us throttle pulse plus a 500 us noise edge into a seemingly
     * valid 1100 us channel value.  This was invisible to bad_frame_count and
     * made the motors slow down as their electrical noise increased. */
    if (interval_us < PPM_GLITCH_MIN_US) {
        rc_state.pulse_error_count++;
        return;
    }

    /* A very long interval starts a fresh measurement; do not try to decode
     * the interrupted frame, but retain this real edge as the next origin. */
    ppm_last_edge_cycles = now_cycles;
    if (interval_us > PPM_PWM_REJECT_US) {
        ppm_ready = 0U;
        ppm_sample_count = 0U;
        rc_state.pulse_error_count++;
        return;
    }

    /* Commit a frame only when the following sync gap proves that the frame
     * contained exactly eight channels.  The old code committed immediately
     * after the eighth edge, so one motor-noise edge could shift an AUX pulse
     * into CH3 while the frame still looked connected. */
    if (interval_us >= PPM_SYNC_MIN_US) {
        if (ppm_ready == 1U) {
            if (ppm_sample_count == PPM_CHANNEL_COUNT) {
                for (i = 0U; i < PPM_CHANNEL_COUNT; i++) {
                    rc_state.channel[i] = ppm_buffer[i];
                }
                ppm_work_count++;
                rc_state.frame_count = ppm_work_count;
                rc_state.last_frame_ms = HAL_GetTick();
                rc_state.connected = 1U;
                rc_state.signal_lost = 0U;
                if (!rc_state.armed) rc_state.failsafe = 0U;
            } else {
                ppm_miss_count++;
                rc_state.bad_frame_count = ppm_miss_count;
            }
        }
        ppm_ready = 1U;
        ppm_sample_count = 0U;
        denominator = ppm_work_count + ppm_miss_count;
        if (denominator != 0U) {
            rc_state.ppm_accuracy = (float)ppm_work_count / (float)denominator;
        }
        return;
    }

    if (ppm_ready == 1U) {
        if (interval_us <= PPM_CHANNEL_MIN_US ||
            interval_us > PPM_CHANNEL_MAX_US) {
            ppm_ready = 0U;
            ppm_sample_count = 0U;
            ppm_miss_count++;
            rc_state.bad_frame_count = ppm_miss_count;
            return;
        }

        if (ppm_sample_count < PPM_CHANNEL_COUNT) {
            ppm_buffer[ppm_sample_count] = (uint16_t)interval_us;
            ppm_sample_count++;
        } else {
            /* More than eight channel pulses before sync: reject the complete
             * frame instead of accepting a shifted channel order. */
            ppm_ready = 0U;
            ppm_sample_count = 0U;
            ppm_miss_count++;
            rc_state.bad_frame_count = ppm_miss_count;
        }
    }
}

void YaoKong_Process(void)
{
    uint32_t now;
    uint32_t primask;
    uint32_t frame_count;
    uint32_t last_frame_ms;
    uint16_t channel[PPM_CHANNEL_COUNT];
    uint8_t armed;
    uint8_t i;
    float roll_command;
    float pitch_command;
    float yaw_command;
    uint8_t throttle_low;

    primask = __get_PRIMASK();
    __disable_irq();
    frame_count = rc_state.frame_count;
    last_frame_ms = rc_state.last_frame_ms;
    armed = rc_state.armed;
    for (i = 0U; i < PPM_CHANNEL_COUNT; i++) channel[i] = rc_state.channel[i];
    if (primask == 0U) __enable_irq();

    /* Read time after copying last_frame_ms.  Previously 'now' was read
     * first; a PPM interrupt could then store a timestamp one tick newer than
     * now.  Unsigned subtraction wrapped to 0xFFFFFFFF and falsely looked
     * like a multi-day signal loss exactly when arming. */
    now = HAL_GetTick();

    if (frame_count == 0U ||
        (uint32_t)(now - last_frame_ms) > YAOKONG_FRAME_TIMEOUT_MS) {
        rc_state.connected = 0U;
        rc_state.signal_lost = 1U;
        rc_state.roll_target_deg = 0.0f;
        rc_state.pitch_target_deg = 0.0f;
        rc_state.yaw_rate_target_dps = 0.0f;
        rc_state.throttle_us = RC_MIN_US;
        if (armed) rc_state.failsafe = 1U;
        failsafe_recovery_count = 0U;
        failsafe_recovery_last_frame_ms = 0U;
        rc_state.failsafe_recovery_count = 0U;
        unlock_confirm_count = 0U;
        lock_confirm_count = 0U;
        return;
    }

    if (rc_state.failsafe) {
        uint8_t sticks_centered;

        if (frame_count == last_processed_frame) return;
        last_processed_frame = frame_count;

        /* A brief airborne PPM dropout used to latch failsafe forever, even
         * after valid frames had returned.  Recover only after a continuous
         * run of complete frames with the attitude sticks centred and a sane
         * throttle, so control cannot return with a large step command. */
        sticks_centered =
            channel[YAOKONG_CH_ROLL] >= RC_MIDDLE_US - RC_DEADBAND_US / 2U &&
            channel[YAOKONG_CH_ROLL] <= RC_MIDDLE_US + RC_DEADBAND_US / 2U &&
            channel[YAOKONG_CH_PITCH] >= RC_MIDDLE_US - RC_DEADBAND_US / 2U &&
            channel[YAOKONG_CH_PITCH] <= RC_MIDDLE_US + RC_DEADBAND_US / 2U &&
            channel[YAOKONG_CH_YAW] >= RC_MIDDLE_US - RC_DEADBAND_US / 2U &&
            channel[YAOKONG_CH_YAW] <= RC_MIDDLE_US + RC_DEADBAND_US / 2U;

        if (sticks_centered &&
            channel[YAOKONG_CH_THROTTLE] <=
                YAOKONG_FAILSAFE_RECOVER_THROTTLE_MAX_US) {
            if (failsafe_recovery_last_frame_ms == 0U ||
                (uint32_t)(last_frame_ms - failsafe_recovery_last_frame_ms) <=
                    YAOKONG_FAILSAFE_RECOVER_GAP_MS) {
                if (failsafe_recovery_count <
                    YAOKONG_FAILSAFE_RECOVER_FRAMES) {
                    failsafe_recovery_count++;
                }
            } else {
                failsafe_recovery_count = 1U;
            }
            failsafe_recovery_last_frame_ms = last_frame_ms;
        } else {
            failsafe_recovery_count = 0U;
            failsafe_recovery_last_frame_ms = 0U;
        }
        rc_state.failsafe_recovery_count = failsafe_recovery_count;

        if (failsafe_recovery_count < YAOKONG_FAILSAFE_RECOVER_FRAMES) return;

        rc_state.failsafe = 0U;
        rc_state.signal_lost = 0U;
        rc_state.connected = 1U;
        failsafe_recovery_count = 0U;
        failsafe_recovery_last_frame_ms = 0U;
    } else {
        failsafe_recovery_count = 0U;
        failsafe_recovery_last_frame_ms = 0U;
        rc_state.failsafe_recovery_count = 0U;
        if (frame_count == last_processed_frame) return;
        last_processed_frame = frame_count;
    }

    /* Official channel order: CH1 roll, CH2 pitch, CH3 throttle, CH4 yaw. */
    roll_command = Remote_DataRemap(channel[YAOKONG_CH_ROLL],
                                    YAOKONG_MAX_TILT_DEG,
                                    YAOKONG_MAX_TILT_DEG, 1U);
    pitch_command = Remote_DataRemap(channel[YAOKONG_CH_PITCH],
                                     YAOKONG_MAX_TILT_DEG,
                                     YAOKONG_MAX_TILT_DEG, 1U);
    yaw_command = Remote_DataRemap(channel[YAOKONG_CH_YAW],
                                   RC_YAW_MAX, RC_YAW_MAX, 0U);

    rc_state.roll_target_deg = YAOKONG_REVERSE_ROLL ? -roll_command : roll_command;
    rc_state.pitch_target_deg = YAOKONG_REVERSE_PITCH ? -pitch_command : pitch_command;
    rc_state.yaw_rate_target_dps = yaw_command;
    if (channel[YAOKONG_CH_THROTTLE] < RC_MIN_US) {
        rc_state.throttle_us = RC_MIN_US;
    } else if (channel[YAOKONG_CH_THROTTLE] > YAOKONG_THROTTLE_MAX_US) {
        rc_state.throttle_us = YAOKONG_THROTTLE_MAX_US;
    } else {
        rc_state.throttle_us = channel[YAOKONG_CH_THROTTLE];
    }

    throttle_low = channel[YAOKONG_CH_THROTTLE]
                 < (uint16_t)(RC_MIN_US + RC_SCALE_US * 0.1f);

    /* Port of unlock_state_check(): high CH4 locks for 1 s in command space;
     * because the official yaw remap is not reversed, a low pulse is +yaw
     * (lock), while a high pulse is -yaw (unlock). */
    if (throttle_low && roll_command == 0.0f && pitch_command == 0.0f &&
        yaw_command >= RC_YAW_MAX * RC_GESTURE_SCALE) {
        if (lock_confirm_count < RC_LOCK_FRAMES) lock_confirm_count++;
    } else {
        lock_confirm_count /= 5U;
    }
    if (lock_confirm_count >= RC_LOCK_FRAMES) {
        rc_state.armed = 0U;
        lock_confirm_count = 0U;
        unlock_confirm_count = 0U;
    }

    if (throttle_low && roll_command == 0.0f && pitch_command == 0.0f &&
        yaw_command <= -RC_YAW_MAX * RC_GESTURE_SCALE) {
        if (unlock_confirm_count < RC_UNLOCK_FRAMES) unlock_confirm_count++;
    } else {
        unlock_confirm_count /= 5U;
    }
    if (unlock_confirm_count >= RC_UNLOCK_FRAMES) {
        rc_state.armed = 1U;
        rc_state.failsafe = 0U;
        rc_state.signal_lost = 0U;
        rc_state.failsafe_recovery_count = 0U;
        failsafe_recovery_count = 0U;
        failsafe_recovery_last_frame_ms = 0U;
        unlock_confirm_count = 0U;
        lock_confirm_count = 0U;
    }
}

void YaoKong_GetSnapshot(YaoKong_State_t *state)
{
    uint32_t primask;
    if (state == 0) return;
    primask = __get_PRIMASK();
    __disable_irq();
    memcpy(state, (const void *)&rc_state, sizeof(*state));
    if (primask == 0U) __enable_irq();
}

#ifndef YAOKONG_H
#define YAOKONG_H

#include "main.h"

#define YAOKONG_CHANNEL_COUNT       16U
#define YAOKONG_CH_ROLL              0U
#define YAOKONG_CH_PITCH             1U
#define YAOKONG_CH_THROTTLE          2U
#define YAOKONG_CH_YAW               3U

#define YAOKONG_MAX_TILT_DEG        5.0f
#define YAOKONG_MAX_YAW_RATE_DPS   60.0f
#define YAOKONG_THROTTLE_MIN_US     1000U
#define YAOKONG_THROTTLE_MAX_US     2000U
/* PPM is normally about 50 Hz.  Do not latch a flight shutdown for one
 * malformed frame or a short receiver resynchronisation.  A real loss must
 * persist continuously for 300 ms before failsafe is asserted. */
#define YAOKONG_FRAME_TIMEOUT_MS     300U
#define YAOKONG_FAILSAFE_RECOVER_FRAMES 30U
#define YAOKONG_FAILSAFE_RECOVER_GAP_MS  60U
#define YAOKONG_FAILSAFE_RECOVER_THROTTLE_MAX_US 1700U

/* If a stick moves in the wrong direction during the propeller-off test,
 * change only the corresponding 0U to 1U. */
#define YAOKONG_REVERSE_ROLL          0U
#define YAOKONG_REVERSE_PITCH         1U

typedef struct {
    uint16_t channel[YAOKONG_CHANNEL_COUNT];
    float roll_target_deg;
    float pitch_target_deg;
    float yaw_rate_target_dps;
    uint16_t throttle_us;
    uint8_t connected;
    uint8_t armed;
    uint8_t signal_lost;
    uint8_t failsafe;
    uint16_t failsafe_recovery_count;
    uint32_t frame_count;
    uint32_t bad_frame_count;
    uint32_t pulse_error_count;
    uint32_t last_frame_ms;
    float ppm_accuracy;
} YaoKong_State_t;

void YaoKong_Init(void);
void YaoKong_Process(void);
void YaoKong_PPM_IRQHandler(void);
void YaoKong_GetSnapshot(YaoKong_State_t *state);

#endif

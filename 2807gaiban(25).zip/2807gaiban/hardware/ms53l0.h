#ifndef __MS53L0_H
#define __MS53L0_H

#include "i2c.h"   /* hi2c2 */

#define MS53L0_ADDR      0x52    /* HAL 8-bit I2C address (7-bit: 0x29) */

#define MS53L0_ASYNC_WAIT   0U
#define MS53L0_ASYNC_READY  1U
#define MS53L0_ASYNC_ERROR  2U

uint8_t  MS53L0_Init(void);      /* return 0=OK, 1=fail */
uint16_t MS53L0_ReadMM(void);    /* mm; 0xFFFE=bad status, 0xFFFF=timeout */
uint8_t  MS53L0_RequestMeasurement(void); /* 1=started, 0=busy/not ready/I2C error */
uint8_t  MS53L0_PollMeasurement(uint16_t *distance_mm); /* WAIT/READY/ERROR */
uint8_t  MS53L0_MeasurementActive(void);

extern uint8_t ms53l0_ready;     /* 1 = init OK, safe to call ReadMM */
extern uint8_t ms53l0_device_status; /* device error code; 11=range complete */
extern uint8_t ms53l0_pal_status;    /* 0=valid, 1=sigma fail, other=device fail */
extern uint16_t ms53l0_sigma_x100;   /* estimated sigma in 0.01 mm */
extern uint16_t ms53l0_signal_q97;   /* return signal rate in sensor Q9.7 */
extern uint32_t ms53l0_runtime_i2c_errors;
extern uint32_t ms53l0_runtime_timeouts;

#endif

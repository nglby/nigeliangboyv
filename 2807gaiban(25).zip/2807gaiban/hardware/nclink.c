#include "nclink.h"
#include <string.h>

#define NCLINK_RX_HEAD0          0xFCU
#define NCLINK_RX_HEAD1          0xFFU
#define NCLINK_TX_HEAD0          0xFFU
#define NCLINK_TX_HEAD1          0xFCU
#define NCLINK_TAIL0             0xA1U
#define NCLINK_TAIL1             0xA2U

#define NCLINK_STATUS            0x01U
#define NCLINK_SEND_PID1_3       0x0AU
#define NCLINK_SEND_PID4_6       0x0BU
#define NCLINK_SEND_CHECK        0xF0U

#define NCLINK_PID_GROUPS        6U
#define NCLINK_PID_VALUES        9U
#define NCLINK_TX_GAP_MS         4U
#define NCLINK_STATUS_PERIOD_MS  20U

static UART_HandleTypeDef *nclink_uart;
static uint8_t rx_buf[32];
static uint8_t rx_state;
static uint8_t rx_len;
static uint8_t rx_count;

static volatile uint8_t read_pid_mask;
static volatile uint8_t write_pid_mask;
static volatile uint8_t restore_default_pending;
static volatile int16_t pending_pid[NCLINK_PID_GROUPS][NCLINK_PID_VALUES];
static uint8_t ack_pid_mask;
static uint32_t last_tx_ms;
static uint32_t last_status_ms;

static float NCLink_Clamp(float value, float low, float high)
{
    if (value < low) return low;
    if (value > high) return high;
    return value;
}

static int16_t NCLink_ReadS16(const uint8_t *data)
{
    return (int16_t)(((uint16_t)data[0] << 8) | data[1]);
}

static void NCLink_PutS16(uint8_t *buf, uint8_t *count, float value, float scale)
{
    int32_t scaled = (int32_t)(value * scale);
    if (scaled > 32767) scaled = 32767;
    if (scaled < -32768) scaled = -32768;
    buf[(*count)++] = (uint8_t)(((uint16_t)scaled >> 8) & 0xFFU);
    buf[(*count)++] = (uint8_t)((uint16_t)scaled & 0xFFU);
}

static void NCLink_PutS32(uint8_t *buf, uint8_t *count, float value, float scale)
{
    int32_t scaled = (int32_t)(value * scale);
    buf[(*count)++] = (uint8_t)(((uint32_t)scaled >> 24) & 0xFFU);
    buf[(*count)++] = (uint8_t)(((uint32_t)scaled >> 16) & 0xFFU);
    buf[(*count)++] = (uint8_t)(((uint32_t)scaled >> 8) & 0xFFU);
    buf[(*count)++] = (uint8_t)((uint32_t)scaled & 0xFFU);
}

static void NCLink_SendFrame(uint8_t function, const uint8_t *payload, uint8_t length)
{
    uint8_t frame[32];
    uint8_t count = 0U;
    uint8_t checksum = 0U;
    uint8_t i;

    if ((nclink_uart == NULL) || (length > 24U)) return;
    frame[count++] = NCLINK_TX_HEAD0;
    frame[count++] = NCLINK_TX_HEAD1;
    frame[count++] = function;
    frame[count++] = length;
    for (i = 0U; i < length; i++) frame[count++] = payload[i];
    for (i = 0U; i < count; i++) checksum ^= frame[i];
    frame[count++] = checksum;
    frame[count++] = NCLINK_TAIL0;
    frame[count++] = NCLINK_TAIL1;
    /* A full 31-byte status frame takes about 2.7 ms at 115200.  TIM3 may
     * preempt this main-loop transmit, so keep enough timeout margin. */
    (void)HAL_UART_Transmit(nclink_uart, frame, count, 10U);
}

static void NCLink_SendCheck(uint8_t response)
{
    NCLink_SendFrame(NCLINK_SEND_CHECK, &response, 1U);
}

static void NCLink_SendPID(uint8_t group,
                           float p1, float i1, float d1,
                           float p2, float i2, float d2,
                           float p3, float i3, float d3)
{
    uint8_t payload[18];
    uint8_t count = 0U;
    NCLink_PutS16(payload, &count, p1, 1000.0f);
    NCLink_PutS16(payload, &count, i1, 1000.0f);
    NCLink_PutS16(payload, &count, d1, 100.0f);
    NCLink_PutS16(payload, &count, p2, 1000.0f);
    NCLink_PutS16(payload, &count, i2, 1000.0f);
    NCLink_PutS16(payload, &count, d2, 100.0f);
    NCLink_PutS16(payload, &count, p3, 1000.0f);
    NCLink_PutS16(payload, &count, i3, 1000.0f);
    NCLink_PutS16(payload, &count, d3, 100.0f);
    NCLink_SendFrame(group, payload, count);
}

static void NCLink_SendStatus(float roll, float pitch, float yaw,
                              float roll_rate, float pitch_rate,
                              float yaw_rate, uint8_t armed)
{
    uint8_t payload[24];
    uint8_t count = 0U;
    NCLink_PutS16(payload, &count, roll, 100.0f);
    NCLink_PutS16(payload, &count, pitch, 100.0f);
    /* Match the official fly source exactly: roll/pitch *100, yaw *10. */
    NCLink_PutS16(payload, &count, yaw, 10.0f);
    NCLink_PutS32(payload, &count, roll_rate, 100.0f);
    NCLink_PutS32(payload, &count, pitch_rate, 100.0f);
    NCLink_PutS32(payload, &count, yaw_rate, 100.0f);
    NCLink_PutS16(payload, &count, 0.0f, 100.0f); /* IMU temperature unavailable */
    NCLink_PutS16(payload, &count, 0.0f, 100.0f); /* battery voltage unavailable */
    payload[count++] = 0U;                       /* flight mode */
    payload[count++] = armed ? 1U : 0U;
    NCLink_SendFrame(NCLINK_STATUS, payload, count);
}

static void NCLink_ParseFrame(void)
{
    uint8_t checksum = 0U;
    uint8_t function = rx_buf[2];
    uint8_t i;

    for (i = 0U; i < (uint8_t)(4U + rx_len); i++) checksum ^= rx_buf[i];
    if (checksum != rx_buf[4U + rx_len]) return;

    if ((function == 0x01U) && (rx_len >= 1U)) {
        if (rx_buf[4] == 0x01U) {
            read_pid_mask = 0x3FU;
        } else if (rx_buf[4] == 0x02U) {
            restore_default_pending = 1U;
        }
    } else if ((function >= 0x02U) && (function <= 0x07U) && (rx_len == 18U)) {
        uint8_t group = (uint8_t)(function - 0x02U);
        for (i = 0U; i < NCLINK_PID_VALUES; i++) {
            pending_pid[group][i] = NCLink_ReadS16(&rx_buf[4U + i * 2U]);
        }
        write_pid_mask |= (uint8_t)(1U << group);
    }
}

void NCLink_Init(UART_HandleTypeDef *huart)
{
    nclink_uart = huart;
    rx_state = 0U;
    rx_len = 0U;
    rx_count = 0U;
    read_pid_mask = 0U;
    write_pid_mask = 0U;
    restore_default_pending = 0U;
    ack_pid_mask = 0U;
    last_tx_ms = HAL_GetTick();
    last_status_ms = last_tx_ms;
    __HAL_UART_CLEAR_OREFLAG(huart);
    __HAL_UART_ENABLE_IT(huart, UART_IT_RXNE);
    __HAL_UART_ENABLE_IT(huart, UART_IT_ERR);
}

void NCLink_RxByteIRQ(uint8_t data)
{
    switch (rx_state) {
    case 0U:
        if (data == NCLINK_RX_HEAD0) {
            rx_buf[0] = data;
            rx_state = 1U;
        }
        break;
    case 1U:
        if (data == NCLINK_RX_HEAD1) {
            rx_buf[1] = data;
            rx_state = 2U;
        } else {
            rx_state = (data == NCLINK_RX_HEAD0) ? 1U : 0U;
        }
        break;
    case 2U:
        if (data < 0xF1U) {
            rx_buf[2] = data;
            rx_state = 3U;
        } else {
            rx_state = 0U;
        }
        break;
    case 3U:
        if ((data > 0U) && (data <= 24U)) {
            rx_buf[3] = data;
            rx_len = data;
            rx_count = 0U;
            rx_state = 4U;
        } else {
            rx_state = 0U;
        }
        break;
    case 4U:
        rx_buf[4U + rx_count++] = data;
        if (rx_count >= rx_len) rx_state = 5U;
        break;
    case 5U:
        rx_buf[4U + rx_len] = data;
        rx_state = 6U;
        break;
    case 6U:
        rx_state = (data == NCLINK_TAIL0) ? 7U : 0U;
        break;
    case 7U:
        if (data == NCLINK_TAIL1) NCLink_ParseFrame();
        rx_state = 0U;
        break;
    default:
        rx_state = 0U;
        break;
    }
}

static void NCLink_ResetFourPID(PID_t *roll_rate, PID_t *pitch_rate,
                                PID_t *roll_angle, PID_t *pitch_angle)
{
    PID_Reset(roll_rate);
    PID_Reset(pitch_rate);
    PID_Reset(roll_angle);
    PID_Reset(pitch_angle);
}

static void NCLink_ApplyGroup(uint8_t group, const int16_t *raw,
                              PID_t *roll_rate, PID_t *pitch_rate, PID_t *yaw_rate,
                              PID_t *roll_angle, PID_t *pitch_angle)
{
    if (group == 0U) {
        roll_rate->kp = NCLink_Clamp(raw[0] * 0.001f, 0.0f, 5.0f);
        roll_rate->ki = NCLink_Clamp(raw[1] * 0.001f, 0.0f, 10.0f);
        roll_rate->kd = NCLink_Clamp(raw[2] * 0.01f,  0.0f, 20.0f);
        pitch_rate->kp = NCLink_Clamp(raw[3] * 0.001f, 0.0f, 5.0f);
        pitch_rate->ki = NCLink_Clamp(raw[4] * 0.001f, 0.0f, 10.0f);
        pitch_rate->kd = NCLink_Clamp(raw[5] * 0.01f,  0.0f, 20.0f);
        yaw_rate->kp = NCLink_Clamp(raw[6] * 0.001f, 0.0f, 10.0f);
        yaw_rate->ki = NCLink_Clamp(raw[7] * 0.001f, 0.0f, 10.0f);
        yaw_rate->kd = NCLink_Clamp(raw[8] * 0.01f,  0.0f, 20.0f);
        PID_Reset(roll_rate);
        PID_Reset(pitch_rate);
        PID_Reset(yaw_rate);
    } else if (group == 1U) {
        roll_angle->kp = NCLink_Clamp(raw[0] * 0.001f, 0.0f, 20.0f);
        roll_angle->ki = NCLink_Clamp(raw[1] * 0.001f, 0.0f, 5.0f);
        roll_angle->kd = NCLink_Clamp(raw[2] * 0.01f,  0.0f, 10.0f);
        pitch_angle->kp = NCLink_Clamp(raw[3] * 0.001f, 0.0f, 20.0f);
        pitch_angle->ki = NCLink_Clamp(raw[4] * 0.001f, 0.0f, 5.0f);
        pitch_angle->kd = NCLink_Clamp(raw[5] * 0.01f,  0.0f, 10.0f);
        PID_Reset(roll_angle);
        PID_Reset(pitch_angle);
    }
}

void NCLink_Service(uint32_t now_ms,
                    PID_t *roll_rate, PID_t *pitch_rate, PID_t *yaw_rate,
                    PID_t *roll_angle, PID_t *pitch_angle,
                    float roll_deg, float pitch_deg, float yaw_deg,
                    float roll_rate_dps, float pitch_rate_dps,
                    float yaw_rate_dps, uint8_t armed,
                    uint8_t allow_pid_write)
{
    uint8_t group;
    uint8_t mask;
    int16_t values[NCLINK_PID_VALUES];
    uint32_t primask;

    primask = __get_PRIMASK();
    __disable_irq();
    mask = write_pid_mask;
    if (mask != 0U) {
        for (group = 0U; group < NCLINK_PID_GROUPS; group++) {
            if ((mask & (uint8_t)(1U << group)) != 0U) break;
        }
        memcpy(values, (const void *)pending_pid[group], sizeof(values));
        write_pid_mask &= (uint8_t)~(1U << group);
    } else {
        group = NCLINK_PID_GROUPS;
    }
    if (primask == 0U) __enable_irq();

    if (group < NCLINK_PID_GROUPS) {
        if (allow_pid_write) {
            primask = __get_PRIMASK();
            __disable_irq();
            NCLink_ApplyGroup(group, values, roll_rate, pitch_rate, yaw_rate,
                              roll_angle, pitch_angle);
            if (primask == 0U) __enable_irq();
            ack_pid_mask |= (uint8_t)(1U << group);
        }
    }

    if (restore_default_pending != 0U) {
        restore_default_pending = 0U;
        if (allow_pid_write) {
            primask = __get_PRIMASK();
            __disable_irq();
            roll_rate->kp = pitch_rate->kp = 0.64f;
            roll_rate->ki = pitch_rate->ki = 0.25f;
            roll_rate->kd = pitch_rate->kd = 0.25f;
            yaw_rate->kp = 0.80f;
            yaw_rate->ki = 0.15f;
            yaw_rate->kd = 0.00f;
            roll_angle->kp = pitch_angle->kp = 7.00f;
            roll_angle->ki = pitch_angle->ki = 0.0f;
            roll_angle->kd = pitch_angle->kd = 0.0f;
            NCLink_ResetFourPID(roll_rate, pitch_rate, roll_angle, pitch_angle);
            PID_Reset(yaw_rate);
            if (primask == 0U) __enable_irq();
            read_pid_mask = 0x3FU;
        }
    }

    if ((uint32_t)(now_ms - last_tx_ms) < NCLINK_TX_GAP_MS) return;

    if (ack_pid_mask != 0U) {
        for (group = 0U; group < NCLINK_PID_GROUPS; group++) {
            if ((ack_pid_mask & (uint8_t)(1U << group)) != 0U) break;
        }
        ack_pid_mask &= (uint8_t)~(1U << group);
        NCLink_SendCheck((uint8_t)(NCLINK_SEND_PID1_3 + group));
        last_tx_ms = now_ms;
        return;
    }

    if (read_pid_mask != 0U) {
        for (group = 0U; group < NCLINK_PID_GROUPS; group++) {
            if ((read_pid_mask & (uint8_t)(1U << group)) != 0U) break;
        }
        read_pid_mask &= (uint8_t)~(1U << group);
        if (group == 0U) {
            NCLink_SendPID(NCLINK_SEND_PID1_3,
                           roll_rate->kp, roll_rate->ki, roll_rate->kd,
                           pitch_rate->kp, pitch_rate->ki, pitch_rate->kd,
                           yaw_rate->kp, yaw_rate->ki, yaw_rate->kd);
        } else if (group == 1U) {
            NCLink_SendPID(NCLINK_SEND_PID4_6,
                           roll_angle->kp, roll_angle->ki, roll_angle->kd,
                           pitch_angle->kp, pitch_angle->ki, pitch_angle->kd,
                           0.0f, 0.0f, 0.0f);
        } else {
            NCLink_SendPID((uint8_t)(NCLINK_SEND_PID1_3 + group),
                           0.0f, 0.0f, 0.0f,
                           0.0f, 0.0f, 0.0f,
                           0.0f, 0.0f, 0.0f);
        }
        last_tx_ms = now_ms;
        return;
    }

    if ((uint32_t)(now_ms - last_status_ms) >= NCLINK_STATUS_PERIOD_MS) {
        NCLink_SendStatus(roll_deg, pitch_deg, yaw_deg,
                          roll_rate_dps, pitch_rate_dps, yaw_rate_dps, armed);
        last_status_ms = now_ms;
        last_tx_ms = now_ms;
    }
}

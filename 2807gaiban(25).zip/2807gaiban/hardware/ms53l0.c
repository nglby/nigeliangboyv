
#include "ms53l0.h"

/* ===== private variables ===== */
static uint8_t stop_var;   /* StopVariable, read during DataInit */
uint8_t ms53l0_ready = 0;  /* 1 = init succeeded, safe to read */
uint8_t ms53l0_device_status = 0xFFU;
uint8_t ms53l0_pal_status = 0xFFU;
uint16_t ms53l0_sigma_x100 = 0xFFFFU;
uint16_t ms53l0_signal_q97 = 0U;
uint32_t ms53l0_runtime_i2c_errors = 0U;
uint32_t ms53l0_runtime_timeouts = 0U;

/* Runtime ranging must never starve the 200 Hz IMU producer.  The original
 * single-shot routine could spend 100 ms in one I2C call and repeated that
 * call in a 2000-iteration polling loop.  A brief ToF bus disturbance then
 * made a healthy BMI088 look stale and latched the motor failsafe. */
#define MS53L0_RUNTIME_I2C_TIMEOUT_MS  2U
#define MS53L0_MEASUREMENT_TIMEOUT_MS 60U

static uint8_t ms53l0_measurement_active = 0U;
static uint32_t ms53l0_measurement_start_ms = 0U;

/* ===== I2C helpers (use hi2c2) ===== */
static void wr(uint8_t reg, uint8_t val)
{
    uint8_t buf[2] = {reg, val};
    HAL_I2C_Master_Transmit(&hi2c2, MS53L0_ADDR, buf, 2, 100);
}

static void wr_word(uint8_t reg, uint16_t val)
{
    uint8_t buf[3] = {reg, (uint8_t)(val >> 8), (uint8_t)val};
    HAL_I2C_Master_Transmit(&hi2c2, MS53L0_ADDR, buf, 3, 100);
}

static uint8_t rd(uint8_t reg)
{
    uint8_t val = 0;
    HAL_I2C_Master_Transmit(&hi2c2, MS53L0_ADDR, &reg, 1, 100);
    HAL_I2C_Master_Receive(&hi2c2, MS53L0_ADDR, &val, 1, 100);
    return val;
}

static void rd_multi(uint8_t reg, uint8_t *buf, uint16_t len)
{
    HAL_I2C_Master_Transmit(&hi2c2, MS53L0_ADDR, &reg, 1, 100);
    HAL_I2C_Master_Receive(&hi2c2, MS53L0_ADDR, buf, len, 100);
}

static uint16_t rd_word(uint8_t reg)
{
    uint8_t buf[2];
    rd_multi(reg, buf, 2);
    return ((uint16_t)buf[0] << 8) | buf[1];
}

static uint32_t rd_dword(uint8_t reg)
{
    uint8_t buf[4];
    rd_multi(reg, buf, 4);
    return ((uint32_t)buf[0] << 24) | ((uint32_t)buf[1] << 16) |
           ((uint32_t)buf[2] << 8) | buf[3];
}

/* Short, status-returning helpers used only after takeoff control is active.
 * Initialisation keeps the slower helpers above because it runs before the
 * motors and control timer are enabled. */
static HAL_StatusTypeDef runtime_wr(uint8_t reg, uint8_t val)
{
    uint8_t buf[2] = {reg, val};
    return HAL_I2C_Master_Transmit(&hi2c2, MS53L0_ADDR, buf, 2,
                                   MS53L0_RUNTIME_I2C_TIMEOUT_MS);
}

static HAL_StatusTypeDef runtime_rd(uint8_t reg, uint8_t *val)
{
    HAL_StatusTypeDef ret;
    ret = HAL_I2C_Master_Transmit(&hi2c2, MS53L0_ADDR, &reg, 1,
                                  MS53L0_RUNTIME_I2C_TIMEOUT_MS);
    if (ret != HAL_OK) return ret;
    return HAL_I2C_Master_Receive(&hi2c2, MS53L0_ADDR, val, 1,
                                  MS53L0_RUNTIME_I2C_TIMEOUT_MS);
}

static HAL_StatusTypeDef runtime_rd_multi(uint8_t reg, uint8_t *buf,
                                          uint16_t len)
{
    HAL_StatusTypeDef ret;
    ret = HAL_I2C_Master_Transmit(&hi2c2, MS53L0_ADDR, &reg, 1,
                                  MS53L0_RUNTIME_I2C_TIMEOUT_MS);
    if (ret != HAL_OK) return ret;
    return HAL_I2C_Master_Receive(&hi2c2, MS53L0_ADDR, buf, len,
                                  MS53L0_RUNTIME_I2C_TIMEOUT_MS);
}

/* ===== Default tuning settings (from ST vl53l0x_tuning.h) ===== */
static const uint8_t DefaultTuningSettings[] = {
    0x01, 0xFF, 0x01,
    0x01, 0x00, 0x00,
    0x01, 0xFF, 0x00,
    0x01, 0x09, 0x00,
    0x01, 0x10, 0x00,
    0x01, 0x11, 0x00,
    0x01, 0x24, 0x01,
    0x01, 0x25, 0xff,
    0x01, 0x75, 0x00,
    0x01, 0xFF, 0x01,
    0x01, 0x4e, 0x2c,
    0x01, 0x48, 0x00,
    0x01, 0x30, 0x20,
    0x01, 0xFF, 0x00,
    0x01, 0x30, 0x09,
    0x01, 0x54, 0x00,
    0x01, 0x31, 0x04,
    0x01, 0x32, 0x03,
    0x01, 0x40, 0x83,
    0x01, 0x46, 0x25,
    0x01, 0x60, 0x00,
    0x01, 0x27, 0x00,
    0x01, 0x50, 0x06,
    0x01, 0x51, 0x00,
    0x01, 0x52, 0x96,
    0x01, 0x56, 0x08,
    0x01, 0x57, 0x30,
    0x01, 0x61, 0x00,
    0x01, 0x62, 0x00,
    0x01, 0x64, 0x00,
    0x01, 0x65, 0x00,
    0x01, 0x66, 0xa0,
    0x01, 0xFF, 0x01,
    0x01, 0x22, 0x32,
    0x01, 0x47, 0x14,
    0x01, 0x49, 0xff,
    0x01, 0x4a, 0x00,
    0x01, 0xFF, 0x00,
    0x01, 0x7a, 0x0a,
    0x01, 0x7b, 0x00,
    0x01, 0x78, 0x21,
    0x01, 0xFF, 0x01,
    0x01, 0x23, 0x34,
    0x01, 0x42, 0x00,
    0x01, 0x44, 0xff,
    0x01, 0x45, 0x26,
    0x01, 0x46, 0x05,
    0x01, 0x40, 0x40,
    0x01, 0x0E, 0x06,
    0x01, 0x20, 0x1a,
    0x01, 0x43, 0x40,
    0x01, 0xFF, 0x00,
    0x01, 0x34, 0x03,
    0x01, 0x35, 0x44,
    0x01, 0xFF, 0x01,
    0x01, 0x31, 0x04,
    0x01, 0x4b, 0x09,
    0x01, 0x4c, 0x05,
    0x01, 0x4d, 0x04,
    0x01, 0xFF, 0x00,
    0x01, 0x44, 0x00,
    0x01, 0x45, 0x20,
    0x01, 0x47, 0x08,
    0x01, 0x48, 0x28,
    0x01, 0x67, 0x00,
    0x01, 0x70, 0x04,
    0x01, 0x71, 0x01,
    0x01, 0x72, 0xfe,
    0x01, 0x76, 0x00,
    0x01, 0x77, 0x00,
    0x01, 0xFF, 0x01,
    0x01, 0x0d, 0x01,
    0x01, 0xFF, 0x00,
    0x01, 0x80, 0x01,
    0x01, 0x01, 0xF8,
    0x01, 0xFF, 0x01,
    0x01, 0x8e, 0x01,
    0x01, 0x00, 0x01,
    0x01, 0xFF, 0x00,
    0x01, 0x80, 0x00,
    0x00, 0x00, 0x00   /* end marker */
};

/* ===== SPAD helpers ===== */
static const uint32_t ref_quadrants[4] = {10, 5, 0, 5};

static uint8_t is_aperture(uint32_t idx)
{
    uint32_t q = idx >> 6;
    return (q < 4 && ref_quadrants[q] == 0) ? 0 : 1;
}

static void get_next_good_spad(uint8_t *map, uint32_t size,
                                uint32_t curr, int32_t *next)
{
    uint32_t c, f;
    uint8_t data;
    *next = -1;
    for (c = curr / 8; c < size; c++) {
        data = map[c];
        f = (c == curr / 8) ? (curr % 8) : 0;
        data >>= f;
        for (; f < 8; f++) {
            if (data & 1) { *next = c * 8 + f; return; }
            data >>= 1;
        }
    }
}

static void enable_spad_bit(uint8_t *arr, uint32_t idx)
{
    arr[idx / 8] |= (1 << (idx % 8));
}

/* ===== NVM read strobe ===== */
static void read_strobe(void)
{
    wr(0x83, 0x00);
    for (uint32_t i = 0; i < 2000; i++) {
        if (rd(0x83) != 0x00) return;
    }
}

/* ===== Read NVM SPAD info (count, type, good SPAD map) ===== */
static void read_nvm_spad_info(uint8_t *count, uint8_t *type, uint8_t *good_map)
{
    uint32_t tmp;

    wr(0x80, 0x01);
    wr(0xFF, 0x01);
    wr(0x00, 0x00);
    wr(0xFF, 0x06);
    uint8_t b = rd(0x83);
    wr(0x83, b | 0x04);
    wr(0xFF, 0x07);
    wr(0x81, 0x01);
    HAL_Delay(1);
    wr(0x80, 0x01);

    /* SPAD count + type */
    wr(0x94, 0x6b);
    read_strobe();
    tmp = rd_dword(0x90);
    *count = (uint8_t)((tmp >> 8) & 0x7F);
    *type  = (uint8_t)((tmp >> 15) & 0x01);

    /* Good SPAD map [0..3] */
    wr(0x94, 0x24);
    read_strobe();
    tmp = rd_dword(0x90);
    good_map[0] = (uint8_t)(tmp >> 24);
    good_map[1] = (uint8_t)(tmp >> 16);
    good_map[2] = (uint8_t)(tmp >> 8);
    good_map[3] = (uint8_t)(tmp);

    /* Good SPAD map [4..5] */
    wr(0x94, 0x25);
    read_strobe();
    tmp = rd_dword(0x90);
    good_map[4] = (uint8_t)(tmp >> 24);
    good_map[5] = (uint8_t)(tmp >> 16);

    /* Cleanup */
    wr(0x81, 0x00);
    wr(0xFF, 0x06);
    b = rd(0x83);
    wr(0x83, b & 0xFB);
    wr(0xFF, 0x01);
    wr(0x00, 0x01);
    wr(0xFF, 0x00);
    wr(0x80, 0x00);
}

/* ===== Set reference SPADs from NVM good SPAD map ===== */
static void set_ref_spads(uint8_t count, uint8_t is_apt, uint8_t *good_map)
{
    uint8_t spad_en[6] = {0};
    uint8_t start_select = 0xB4;
    uint32_t max_spads = 44;
    uint32_t curr = 0;
    int32_t next;

    wr(0xFF, 0x01);
    wr(0x4F, 0x00);
    wr(0x4E, 0x2C);
    wr(0xFF, 0x00);
    wr(0xB6, start_select);

    /* If aperture, skip to first aperture SPAD */
    if (is_apt) {
        while (!is_aperture(start_select + curr) && curr < max_spads)
            curr++;
    }

    /* Enable 'count' good SPADs of the correct type */
    for (uint32_t i = 0; i < count; i++) {
        get_next_good_spad(good_map, 6, curr, &next);
        if (next < 0) break;
        if (is_aperture(start_select + (uint32_t)next) != is_apt) break;
        curr = (uint32_t)next;
        enable_spad_bit(spad_en, curr);
        curr++;
    }

    /* Write SPAD enable map to 0xB0..0xB5 */
    for (int i = 0; i < 6; i++)
        wr(0xB0 + i, spad_en[i]);
}

/* ===== Single reference calibration (VHV or phase) ===== */
static void perform_single_ref_cal(uint8_t vhv_init_byte)
{
    wr(0x00, 0x01 | vhv_init_byte);   /* SYSRANGE_START */

    /* Poll RESULT_RANGE_STATUS bit0 until data ready */
    for (uint32_t i = 0; i < 2000; i++) {
        if (rd(0x14) & 0x01) break;
    }

    /* Clear interrupt */
    wr(0x0B, 0x01);
    wr(0x0B, 0x00);
    wr(0x00, 0x00);   /* stop */
}

/* ===== Reference calibration: VHV + Phase ===== */
static void perform_ref_cal(uint8_t *vhv, uint8_t *phase)
{
    uint8_t seq_save = rd(0x01);   /* save SEQUENCE_CONFIG (0xF8 from tuning) */

    /* --- VHV calibration --- */
    wr(0x01, 0x01);                /* SEQUENCE_CONFIG = VHV only */
    perform_single_ref_cal(0x40);

    /* Read VHV result from 0xCB */
    wr(0xFF, 0x01); wr(0x00, 0x00); wr(0xFF, 0x00);
    *vhv = rd(0xCB);
    wr(0xFF, 0x01); wr(0x00, 0x01); wr(0xFF, 0x00);

    /* --- Phase calibration --- */
    wr(0x01, 0x02);                /* SEQUENCE_CONFIG = phase only */
    perform_single_ref_cal(0x00);

    /* Read phase result from 0xEE */
    wr(0xFF, 0x01); wr(0x00, 0x00); wr(0xFF, 0x00);
    *phase = rd(0xEE) & 0xEF;
    wr(0xFF, 0x01); wr(0x00, 0x01); wr(0xFF, 0x00);

    /* Restore SEQUENCE_CONFIG */
    wr(0x01, seq_save);
}

/* ===== ST UM2039 long-range profile support ===== */
typedef struct {
    uint8_t tcc, dss, msrc, pre_range, final_range;
} MS53L0_SeqEnable_t;

typedef struct {
    uint16_t pre_mclks, final_mclks, msrc_mclks;
    uint32_t pre_us, final_us, msrc_us;
    uint8_t pre_vcsel, final_vcsel;
} MS53L0_SeqTimeout_t;

#define MS53L0_TIMING_BUDGET_US 33000UL
#define MS53L0_LONG_SIGMA_LIMIT_Q16 (60UL << 16)
#define MS53L0_MACRO_PERIOD_NS(pclks) \
    ((((uint32_t)2304U * (pclks) * 1655U) + 500U) / 1000U)

static uint8_t decode_vcsel(uint8_t reg)
{
    return (uint8_t)((reg + 1U) << 1);
}

static uint16_t decode_timeout(uint16_t reg)
{
    return (uint16_t)(((reg & 0x00FFU) <<
                      ((reg & 0xFF00U) >> 8)) + 1U);
}

static uint16_t encode_timeout(uint32_t mclks)
{
    uint32_t ls = 0;
    uint16_t ms = 0;
    if (mclks == 0U) return 0U;
    ls = mclks - 1U;
    while ((ls & 0xFFFFFF00UL) != 0U) {
        ls >>= 1;
        ms++;
    }
    return (uint16_t)((ms << 8) | (ls & 0xFFU));
}

static uint32_t timeout_to_us(uint16_t mclks, uint8_t vcsel)
{
    uint32_t macro_ns = MS53L0_MACRO_PERIOD_NS(vcsel);
    return ((uint32_t)mclks * macro_ns + 500U) / 1000U;
}

static uint32_t timeout_to_mclks(uint32_t us, uint8_t vcsel)
{
    uint32_t macro_ns = MS53L0_MACRO_PERIOD_NS(vcsel);
    return (us * 1000U + macro_ns / 2U) / macro_ns;
}

static void get_sequence(MS53L0_SeqEnable_t *e, MS53L0_SeqTimeout_t *t);

static uint32_t isqrt_u32(uint32_t num)
{
    uint32_t res = 0U;
    uint32_t bit = 1UL << 30;
    while (bit > num) bit >>= 2;
    while (bit != 0U) {
        if (num >= res + bit) {
            num -= res + bit;
            res = (res >> 1) + bit;
        } else {
            res >>= 1;
        }
        bit >>= 2;
    }
    return res;
}

/* Sigma estimator used by ST's PAL for CHECKENABLE_SIGMA_FINAL_RANGE.
 * This compact port assumes cross-talk compensation is disabled, matching
 * this driver. Return format is unsigned Q16.16 millimetres. */
static uint32_t calc_sigma_q16(const uint8_t *buf, uint16_t range_mm)
{
    const uint32_t pulse_width_centi_ns = 800U;
    const uint32_t ambient_width_centi_ns = 600U;
    const uint32_t sigma_max_q16 = 0x028F87AEUL;
    const uint32_t sigma_rtn_max_q16 = 0x0000F000UL;
    const uint32_t ambient_ratio_max = 0xF0000000UL / 600U;
    const uint32_t tof_per_mm_ps_q16 = 0x0006999AUL;
    MS53L0_SeqEnable_t e;
    MS53L0_SeqTimeout_t t;
    uint32_t signal_q16 = (uint32_t)(((uint16_t)buf[6] << 8) | buf[7]) << 9;
    uint32_t ambient_q16 = (uint32_t)(((uint16_t)buf[8] << 8) | buf[9]) << 9;
    uint32_t ambient_kcps = (ambient_q16 * 1000U) >> 16;
    uint32_t peak_kcps = (signal_q16 * 1000U + 0x8000U) >> 16;
    uint32_t total_q2408, events, peak_duration_us;
    uint32_t sigma_p2, sigma_p3, pw_mult;
    uint32_t sqr1, sqr2, sqrt_centi_ns, sigma_rtn;
    uint32_t integration_ms, sigma_ref, sigma;

    if (peak_kcps == 0U) return sigma_max_q16;
    get_sequence(&e, &t);
    peak_duration_us = 3U * 2048U * ((uint32_t)t.pre_mclks + t.final_mclks);
    peak_duration_us = (peak_duration_us + 500U) / 1000U;
    peak_duration_us = (peak_duration_us * 1655U + 500U) / 1000U;
    total_q2408 = (signal_q16 + 0x80U) >> 8;
    events = (total_q2408 * peak_duration_us + 0x80U) >> 8;
    if (events < 1U) events = 1U;

    sigma_p2 = (ambient_kcps << 16) / peak_kcps;
    if (sigma_p2 > ambient_ratio_max) sigma_p2 = ambient_ratio_max;
    sigma_p2 *= ambient_width_centi_ns;
    sigma_p3 = 2U * isqrt_u32(events * 12U);
    if (sigma_p3 == 0U) return sigma_max_q16;

    /* With cross-talk disabled, ST's pulse-width multiplier resolves to 1.0. */
    (void)range_mm;
    (void)tof_per_mm_ps_q16;
    pw_mult = 1UL << 16;
    sqr1 = (pw_mult * pulse_width_centi_ns + 0x8000U) >> 16;
    sqr1 *= sqr1;
    sqr2 = (sigma_p2 + 0x8000U) >> 16;
    sqr2 *= sqr2;
    sqrt_centi_ns = isqrt_u32(sqr1 + sqr2) << 16;
    sigma_rtn = (((sqrt_centi_ns + 50U) / 100U) / sigma_p3) * 2997U;
    sigma_rtn = (sigma_rtn + 5000U) / 10000U;
    if (sigma_rtn > sigma_rtn_max_q16) sigma_rtn = sigma_rtn_max_q16;

    integration_ms = (t.final_us + t.pre_us + 500U) / 1000U;
    if (integration_ms == 0U) return sigma_max_q16;
    sigma_ref = isqrt_u32((0x00190000UL + integration_ms / 2U) /
                          integration_ms);
    sigma_ref = ((sigma_ref << 8) + 500U) / 1000U;
    sqr1 = sigma_rtn * sigma_rtn;
    sqr2 = sigma_ref * sigma_ref;
    sigma = 1000U * isqrt_u32(sqr1 + sqr2);
    if (peak_kcps < 1U || events < 1U || sigma > sigma_max_q16)
        sigma = sigma_max_q16;
    return sigma;
}

static void get_sequence(MS53L0_SeqEnable_t *e, MS53L0_SeqTimeout_t *t)
{
    uint8_t seq = rd(0x01);
    e->tcc = (seq >> 4) & 1U;
    e->dss = (seq >> 3) & 1U;
    e->msrc = (seq >> 2) & 1U;
    e->pre_range = (seq >> 6) & 1U;
    e->final_range = (seq >> 7) & 1U;

    t->pre_vcsel = decode_vcsel(rd(0x50));
    t->msrc_mclks = (uint16_t)rd(0x46) + 1U;
    t->msrc_us = timeout_to_us(t->msrc_mclks, t->pre_vcsel);
    t->pre_mclks = decode_timeout(rd_word(0x51));
    t->pre_us = timeout_to_us(t->pre_mclks, t->pre_vcsel);
    t->final_vcsel = decode_vcsel(rd(0x70));
    t->final_mclks = decode_timeout(rd_word(0x71));
    if (e->pre_range && t->final_mclks > t->pre_mclks)
        t->final_mclks -= t->pre_mclks;
    t->final_us = timeout_to_us(t->final_mclks, t->final_vcsel);
}

static uint8_t set_timing_budget(uint32_t budget_us)
{
    const uint16_t start_ov = 1910U, end_ov = 960U;
    const uint16_t msrc_ov = 660U, tcc_ov = 590U, dss_ov = 690U;
    const uint16_t pre_ov = 660U, final_ov = 550U;
    MS53L0_SeqEnable_t e;
    MS53L0_SeqTimeout_t t;
    uint32_t used = (uint32_t)start_ov + end_ov;
    uint32_t final_us, final_mclks;

    if (budget_us < 20000U) return 0U;
    get_sequence(&e, &t);
    if (e.tcc) used += t.msrc_us + tcc_ov;
    if (e.dss) used += 2U * (t.msrc_us + dss_ov);
    else if (e.msrc) used += t.msrc_us + msrc_ov;
    if (e.pre_range) used += t.pre_us + pre_ov;
    if (!e.final_range || used + final_ov > budget_us) return 0U;

    final_us = budget_us - used - final_ov;
    final_mclks = timeout_to_mclks(final_us, t.final_vcsel);
    if (e.pre_range) final_mclks += t.pre_mclks;
    wr_word(0x71, encode_timeout(final_mclks));
    return 1U;
}

static uint8_t set_vcsel(uint8_t final_range, uint8_t pclks)
{
    MS53L0_SeqEnable_t e;
    MS53L0_SeqTimeout_t t;
    uint32_t mclks;
    uint8_t seq;

    get_sequence(&e, &t);
    if (!final_range) {
        if (pclks != 18U) return 0U;
        wr(0x57, 0x50); wr(0x56, 0x08);
        wr(0x50, (pclks >> 1) - 1U);
        mclks = timeout_to_mclks(t.pre_us, pclks);
        wr_word(0x51, encode_timeout(mclks));
        mclks = timeout_to_mclks(t.msrc_us, pclks);
        wr(0x46, (uint8_t)((mclks > 256U) ? 255U : (mclks - 1U)));
    } else {
        if (pclks != 14U) return 0U;
        wr(0x48, 0x48); wr(0x47, 0x08); wr(0x32, 0x03); wr(0x30, 0x07);
        wr(0xFF, 0x01); wr(0x30, 0x20); wr(0xFF, 0x00);
        wr(0x70, (pclks >> 1) - 1U);
        mclks = timeout_to_mclks(t.final_us, pclks);
        if (e.pre_range) mclks += t.pre_mclks;
        wr_word(0x71, encode_timeout(mclks));
    }

    if (!set_timing_budget(MS53L0_TIMING_BUDGET_US)) return 0U;
    seq = rd(0x01);
    wr(0x01, 0x02);
    perform_single_ref_cal(0x00);
    wr(0x01, seq);
    return 1U;
}

static uint8_t set_long_range_profile(void)
{
    /* 0.1 MCPS in Q9.7: round(0.1 * 128) = 13. */
    wr_word(0x44, 13U);
    if (!set_timing_budget(MS53L0_TIMING_BUDGET_US)) return 0U;
    if (!set_vcsel(0U, 18U)) return 0U;
    if (!set_vcsel(1U, 14U)) return 0U;
    return (rd_word(0x44) == 13U &&
            decode_vcsel(rd(0x50)) == 18U &&
            decode_vcsel(rd(0x70)) == 14U) ? 1U : 0U;
}

/* ===== Public API: Init ===== */
uint8_t MS53L0_Init(void)
{
    HAL_Delay(10);

    /* 1. Verify Model ID (0xC0 should be 0xEEAA) */
    uint16_t id = rd_word(0xC0);
    if (id != 0xEEAA) return 1;

    /* 2. DataInit: I2C standard mode + read StopVariable */
    wr(0x88, 0x00);

    wr(0x80, 0x01);
    wr(0xFF, 0x01);
    wr(0x00, 0x00);
    stop_var = rd(0x91);
    wr(0x00, 0x01);
    wr(0xFF, 0x00);
    wr(0x80, 0x00);

    wr(0x01, 0xFF);   /* SEQUENCE_CONFIG = 0xFF (all enabled) */

    /* 3. Apply DefaultTuningSettings */
    for (uint16_t i = 0; DefaultTuningSettings[i] != 0x00; i += 3) {
        if (DefaultTuningSettings[i] == 0x01)
            wr(DefaultTuningSettings[i + 1], DefaultTuningSettings[i + 2]);
    }

    /* 4. Read NVM SPAD info */
    uint8_t spad_count = 0, spad_type = 0;
    uint8_t good_map[6] = {0};
    read_nvm_spad_info(&spad_count, &spad_type, good_map);

    /* 5. Set reference SPADs */
    if (spad_type <= 1 &&
        ((spad_type == 1 && spad_count <= 32) ||
         (spad_type == 0 && spad_count <= 12))) {
        /* NVM values valid */
        set_ref_spads(spad_count, spad_type, good_map);
    } else {
        /* NVM invalid, use 5 non-aperture SPADs as fallback */
        set_ref_spads(5, 0, good_map);
    }

    /* 6. Reference calibration (VHV + phase) */
    uint8_t vhv = 0, phase = 0;
    perform_ref_cal(&vhv, &phase);

    /* Exact UM2039 section 7.2 long-range profile: signal rate 0.1 MCPS,
     * sigma 60 mm (checked per result), 33 ms, VCSEL 18/14 PCLK. */
    if (!set_long_range_profile()) return 1;

    /* 7. Single-shot mode */
    wr(0x00, 0x00);

    HAL_Delay(10);
    ms53l0_ready = 1;
    return 0;
}

/* ===== Runtime non-blocking single-shot API ===== */
uint8_t MS53L0_RequestMeasurement(void)
{
    HAL_StatusTypeDef ret = HAL_OK;

    if (!ms53l0_ready || ms53l0_measurement_active) return 0U;

    /* StartMeasurement sequence (restore StopVariable).  Every transaction is
     * bounded to 2 ms; on any failure the main loop remains responsive. */
    if (runtime_wr(0x80, 0x01) != HAL_OK) ret = HAL_ERROR;
    if (ret == HAL_OK && runtime_wr(0xFF, 0x01) != HAL_OK) ret = HAL_ERROR;
    if (ret == HAL_OK && runtime_wr(0x00, 0x00) != HAL_OK) ret = HAL_ERROR;
    if (ret == HAL_OK && runtime_wr(0x91, stop_var) != HAL_OK) ret = HAL_ERROR;
    if (ret == HAL_OK && runtime_wr(0x00, 0x01) != HAL_OK) ret = HAL_ERROR;
    if (ret == HAL_OK && runtime_wr(0xFF, 0x00) != HAL_OK) ret = HAL_ERROR;
    if (ret == HAL_OK && runtime_wr(0x80, 0x00) != HAL_OK) ret = HAL_ERROR;
    if (ret == HAL_OK && runtime_wr(0x00, 0x01) != HAL_OK) ret = HAL_ERROR;

    if (ret != HAL_OK) {
        ms53l0_runtime_i2c_errors++;
        ms53l0_device_status = 0xFFU;
        ms53l0_pal_status = 0xFFU;
        ms53l0_measurement_active = 0U;
        return 0U;
    }

    ms53l0_measurement_start_ms = HAL_GetTick();
    ms53l0_measurement_active = 1U;
    return 1U;
}

uint8_t MS53L0_MeasurementActive(void)
{
    return ms53l0_measurement_active;
}

uint8_t MS53L0_PollMeasurement(uint16_t *distance_mm)
{
    uint8_t status;
    uint8_t buf[12];
    uint16_t dist;
    uint32_t sigma_q16;
    uint32_t sigma_x100;

    if (distance_mm == 0 || !ms53l0_measurement_active)
        return MS53L0_ASYNC_WAIT;

    if ((uint32_t)(HAL_GetTick() - ms53l0_measurement_start_ms) >
        MS53L0_MEASUREMENT_TIMEOUT_MS) {
        /* Best-effort interrupt clear.  Failure is recorded, never waited on. */
        if (runtime_wr(0x0B, 0x01) != HAL_OK ||
            runtime_wr(0x0B, 0x00) != HAL_OK) {
            ms53l0_runtime_i2c_errors++;
        }
        ms53l0_runtime_timeouts++;
        ms53l0_measurement_active = 0U;
        ms53l0_device_status = 0xFFU;
        ms53l0_pal_status = 0xFFU;
        *distance_mm = 0xFFFFU;
        return MS53L0_ASYNC_ERROR;
    }

    /* One quick readiness check per main-loop pass replaces 2000 blocking
     * polls.  A transient I2C error is retried until the 60 ms deadline. */
    if (runtime_rd(0x14, &status) != HAL_OK) {
        ms53l0_runtime_i2c_errors++;
        return MS53L0_ASYNC_WAIT;
    }
    if ((status & 0x01U) == 0U) return MS53L0_ASYNC_WAIT;

    if (runtime_rd_multi(0x14, buf, 12) != HAL_OK) {
        ms53l0_runtime_i2c_errors++;
        return MS53L0_ASYNC_WAIT;
    }

    ms53l0_device_status = (uint8_t)((buf[0] & 0x78U) >> 3);
    ms53l0_signal_q97 = (uint16_t)(((uint16_t)buf[6] << 8) | buf[7]);
    dist = ((uint16_t)buf[10] << 8) | buf[11];
    sigma_q16 = calc_sigma_q16(buf, dist);
    sigma_x100 = (sigma_q16 * 100U + 0x8000U) >> 16;
    ms53l0_sigma_x100 = (uint16_t)((sigma_x100 > 65535U) ?
                                   65535U : sigma_x100);

    if (runtime_wr(0x0B, 0x01) != HAL_OK ||
        runtime_wr(0x0B, 0x00) != HAL_OK) {
        ms53l0_runtime_i2c_errors++;
    }
    ms53l0_measurement_active = 0U;

    if (ms53l0_device_status != 11U) {
        if (ms53l0_device_status == 1U ||
            ms53l0_device_status == 2U ||
            ms53l0_device_status == 3U) {
            ms53l0_pal_status = 5U;
        } else if (ms53l0_device_status == 6U ||
                   ms53l0_device_status == 9U) {
            ms53l0_pal_status = 4U;
        } else if (ms53l0_device_status == 8U ||
                   ms53l0_device_status == 10U) {
            ms53l0_pal_status = 3U;
        } else if (ms53l0_device_status == 4U) {
            ms53l0_pal_status = 2U;
        } else {
            ms53l0_pal_status = 0xFFU;
        }
        *distance_mm = 0xFFFEU;
        return MS53L0_ASYNC_READY;
    }
    if (sigma_q16 > MS53L0_LONG_SIGMA_LIMIT_Q16) {
        ms53l0_pal_status = 1U;
        *distance_mm = 0xFFFEU;
        return MS53L0_ASYNC_READY;
    }

    ms53l0_pal_status = 0U;
    *distance_mm = dist;
    return MS53L0_ASYNC_READY;
}

/* Compatibility wrapper for old callers.  Runtime flight code uses the
 * non-blocking API above; this wrapper is bounded to roughly 60 ms. */
uint16_t MS53L0_ReadMM(void)
{
    uint16_t distance = 0xFFFFU;
    uint8_t state;
    uint32_t start;

    if (!MS53L0_RequestMeasurement()) return 0xFFFFU;
    start = HAL_GetTick();
    do {
        state = MS53L0_PollMeasurement(&distance);
        if (state == MS53L0_ASYNC_READY) return distance;
        if (state == MS53L0_ASYNC_ERROR) return 0xFFFFU;
    } while ((uint32_t)(HAL_GetTick() - start) <=
             (MS53L0_MEASUREMENT_TIMEOUT_MS + 2U));

    ms53l0_measurement_active = 0U;
    return 0xFFFFU;
}

#if 0
/* Legacy blocking implementation retained only as a protocol reference. */
uint16_t MS53L0_ReadMM_Legacy(void)
{
    if (!ms53l0_ready) {
        ms53l0_device_status = 0xFFU;
        ms53l0_pal_status = 0xFFU;
        return 0xFFFF;
    }

    /* StartMeasurement sequence (restore StopVariable) */
    wr(0x80, 0x01);
    wr(0xFF, 0x01);
    wr(0x00, 0x00);
    wr(0x91, stop_var);
    wr(0x00, 0x01);
    wr(0xFF, 0x00);
    wr(0x80, 0x00);

    /* Trigger single measurement */
    wr(0x00, 0x01);

    /* Wait for start bit to clear */
    for (uint32_t i = 0; i < 2000; i++) {
        if (!(rd(0x00) & 0x01)) break;
    }

    /* Poll for data ready (RESULT_RANGE_STATUS bit0) */
    for (uint32_t i = 0; i < 2000; i++) {
        if (rd(0x14) & 0x01) {
            /* Read 12 bytes from 0x14 */
            uint8_t buf[12];
            rd_multi(0x14, buf, 12);
            ms53l0_device_status = (uint8_t)((buf[0] & 0x78U) >> 3);
            ms53l0_signal_q97 = (uint16_t)(((uint16_t)buf[6] << 8) | buf[7]);
            /* Distance in buf[10]:buf[11] (big endian) */
            uint16_t dist = ((uint16_t)buf[10] << 8) | buf[11];
            uint32_t sigma_q16 = calc_sigma_q16(buf, dist);
            uint32_t sigma_x100 = (sigma_q16 * 100U + 0x8000U) >> 16;
            ms53l0_sigma_x100 = (uint16_t)((sigma_x100 > 65535U) ?
                                           65535U : sigma_x100);

            /* Clear interrupt */
            wr(0x0B, 0x01);
            wr(0x0B, 0x00);
            if (ms53l0_device_status != 11U) {
                /* Match VL53L0X_get_pal_range_status() from ST's API. */
                if (ms53l0_device_status == 1U ||
                    ms53l0_device_status == 2U ||
                    ms53l0_device_status == 3U) {
                    ms53l0_pal_status = 5U; /* hardware fail */
                } else if (ms53l0_device_status == 6U ||
                           ms53l0_device_status == 9U) {
                    ms53l0_pal_status = 4U; /* phase fail */
                } else if (ms53l0_device_status == 8U ||
                           ms53l0_device_status == 10U) {
                    ms53l0_pal_status = 3U; /* minimum range fail */
                } else if (ms53l0_device_status == 4U) {
                    ms53l0_pal_status = 2U; /* signal fail */
                } else {
                    ms53l0_pal_status = 0xFFU; /* no usable result */
                }
                return 0xFFFE;
            }
            if (sigma_q16 > MS53L0_LONG_SIGMA_LIMIT_Q16) {
                ms53l0_pal_status = 1U;
                return 0xFFFE;
            }
            ms53l0_pal_status = 0U;
            return dist;
        }
    }

    /* Timeout */
    wr(0x0B, 0x01);
    wr(0x0B, 0x00);
    ms53l0_device_status = 0xFFU;
    ms53l0_pal_status = 0xFFU;
    return 0xFFFF;
}
#endif

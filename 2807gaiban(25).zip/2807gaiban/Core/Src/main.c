/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "bmi088.h"
#include <math.h>
#include <stdio.h>
#include "pid.h"
#include "yaokong.h"
#include "ms53l0.h"
#include "guangliu.h"
#include "nclink.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* 当前姿态控制尚未使用光流数据。逐字节UART中断会高频抢占控制环，
 * 姿态调通前先关闭；以后接入位置环时应改为DMA循环接收后再置1。 */
#define ENABLE_OPTICAL_FLOW  1U /* LC306 receive plus horizontal hold control. */
#define ENABLE_ASCII_DEBUG   1U
#define ENABLE_NCLINK        0U /* Keep USART1 as readable text during this test. */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile float    tof_height_mm = 0.0f;     // 滤波后的TOF高度，供TIM3中断读取
volatile uint8_t  tof_height_valid = 0;     // 1=有有效高度
volatile uint16_t tof_raw_mm = 0;           // TOF原始读数
volatile uint32_t tof_read_cnt = 0;         // 读取计数
volatile uint32_t tof_timeout_cnt = 0;      // 超时计数
volatile uint32_t tof_last_valid_ms = 0U;
volatile uint32_t tof_update_seq = 0U;
/* 高度PID */
PID_t pid_height;               // 高度PID控制器
volatile float    height_target_mm = 500.0f; // 目标高度
volatile uint8_t  alt_hold_enabled = 0;      // 定高开关，0=手动油门 1=定高
volatile uint8_t  alt_hold_request_cmd = 0U;
volatile uint8_t  alt_hold_switch_request_cmd = 0U;
volatile uint8_t  alt_hold_auto_latched = 0U;
volatile uint8_t  alt_hold_recenter_cmd = 0U;
volatile uint8_t  alt_hold_fault = 0U;
volatile float    alt_hold_hover_pwm = 0.0f;
volatile float    alt_hold_output_pwm = 0.0f;
volatile float    alt_hold_vz_mm_s = 0.0f;
volatile float    tof_vz_est_mm_s = 0.0f;
volatile float    tof_vz_last_height_mm = 0.0f;
volatile uint32_t tof_vz_last_ms = 0U;
volatile float    alt_hold_stick_center_pwm = 1500.0f;
volatile uint8_t  alt_hold_capture_settle_debug = 0U;
uint16_t          alt_auto_stable_anchor_us = 1000U;
uint32_t          alt_auto_last_move_ms = 0U;
uint32_t          alt_auto_release_since_ms = 0U;
uint32_t          alt_auto_vz_stable_since_ms = 0U;
uint8_t           alt_auto_stable_capture_done = 0U;
uint8_t           alt_auto_airborne_seen = 0U;

/* 高度低通滤波状态 */
float             height_lpf = 0.0f;        // 低通滤波值

BMI088_Data_t imu;
volatile BMI088_Data_t imu_latest_raw;
volatile uint32_t imu_latest_seq = 0U;
volatile uint32_t imu_latest_ms = 0U;
volatile uint32_t imu_bus_read_fail = 0U;
volatile float pitch = 0, roll = 0, yaw = 0;
/* Physical-level measurements gave pitch 0.00 deg, roll -1.61 deg.  Repeated
 * flights in log78 required negative pitch to oppose the same-direction drift,
 * so apply only a conservative first hover trim; do not copy the -5 deg
 * recovery command into the neutral attitude. */
#define FRAME_LEVEL_PITCH_DEG (-2.20f)
#define FRAME_LEVEL_ROLL_DEG  (-0.80f)
volatile float level_pitch_ref_deg = FRAME_LEVEL_PITCH_DEG;
volatile float level_roll_ref_deg = FRAME_LEVEL_ROLL_DEG;
float gx_off = 0, gy_off = 0, gz_off = 0;
PID_t pid_pitch, pid_roll;             /* 外环: 角度PID */
PID_t pid_pitch_rate, pid_roll_rate;   /* 内环: 角速度PID */
PID_t pid_yaw_rate;
PID_t pid_flow_x, pid_flow_y;
filter_parameter accel_lpf_param, gyro_lpf_param;
filter_buffer accel_lpf_buf[3], gyro_lpf_buf[3];
Mixer_t mixer;
volatile float pitch_target_cmd = 0.0f;
volatile float roll_target_cmd = 0.0f;
volatile float throttle_target_cmd = 1000.0f;
volatile float yaw_rate_target_cmd = 0.0f;
volatile float yaw_heading_target_deg = 0.0f;
volatile float yaw_hold_rate_debug = 0.0f;
volatile float flow_roll_correction_deg = 0.0f;
volatile float flow_pitch_correction_deg = 0.0f;
volatile float flow_angle_limit_debug = 0.0f;
volatile uint8_t flow_hold_active = 0U;
volatile uint8_t flow_hold_effective = 0U;
volatile uint8_t flow_velocity_seeded_debug = 0U;
volatile uint8_t flow_hold_request_cmd = 0U;
volatile uint8_t flow_hold_fault = 0U;
volatile uint32_t flow_sample_seq = 0U;
volatile uint32_t flow_last_sample_ms = 0U;
volatile float flow_body_vx_mm_s = 0.0f;
volatile float flow_body_vy_mm_s = 0.0f;
volatile float flow_body_x_mm = 0.0f;
volatile float flow_body_y_mm = 0.0f;
volatile float flow_hold_blend = 0.0f;
volatile float flow_raw_vx_mm_s = 0.0f;
volatile float flow_raw_vy_mm_s = 0.0f;
volatile float flow_earth_vx_mm_s = 0.0f;
volatile float flow_earth_vy_mm_s = 0.0f;
volatile float flow_desired_earth_vx_mm_s = 0.0f;
volatile float flow_desired_earth_vy_mm_s = 0.0f;
volatile float flow_desired_body_vx_mm_s = 0.0f;
volatile float flow_desired_body_vy_mm_s = 0.0f;
volatile float flow_gyro_x_rad_s = 0.0f;
volatile float flow_gyro_y_rad_s = 0.0f;
volatile float flow_ground_height_mm = 0.0f;
volatile uint8_t flow_ground_height_valid = 0U;
volatile float throttle_slewed_cmd = 1000.0f;
uint32_t imu_ok = 0, imu_fail = 0;
volatile uint8_t imu_consecutive_fail = 0;
volatile uint8_t imu_failsafe_active = 0;
volatile uint8_t rc_failsafe_active = 0;
volatile float imu_failsafe_pwm = 990.0f;
volatile uint8_t auto_land_active = 0U;
volatile uint8_t auto_land_complete = 0U;
volatile uint8_t auto_land_reason = 0U; /* 1=CH6, 2=RC loss, 3=height ceiling */
volatile uint8_t ceiling_land_pilot_override = 0U;
volatile uint8_t auto_land_state = 0U;  /* 0=idle, 1=descent, 2=touchdown ramp, 3=stopped */
volatile float auto_land_target_mm = 0.0f;
volatile float auto_land_output_pwm = 990.0f;
volatile float auto_land_relative_mm = 0.0f;
volatile float auto_land_vz_mm_s = 0.0f;
volatile uint32_t control_last_cycles = 0;
volatile uint32_t control_max_cycles = 0;
volatile uint32_t control_overrun = 0;
volatile uint8_t mixer_saturated = 0;
volatile uint16_t throttle_base_debug = 1000;
volatile uint8_t startup_phase_debug = 1;
volatile float attitude_fade_debug = 0.0f;
volatile uint8_t motor_idle_ramp_active = 0U;
volatile float motor_idle_ramp_pwm = 1000.0f;
volatile float attitude_integral_scale = 0.0f;
volatile float motor_trim_blend_debug = 0.0f;
volatile uint8_t takeoff_guard_active_debug = 0U;
uint8_t debug_mode = 0;  /* Flight mode: CH5 altitude hold, automatic point hold. */

#define CONTROL_DT        0.005f   /* 与官方一致: TIM3 = 200Hz, dt固定5ms */
#define ATTITUDE_ALPHA    0.985f   /* 降低高转速振动和水平加速度对姿态角的干扰 */
#define ANGLE_KP_FIXED    7.0f     /* Slightly stronger low-frequency attitude return. */
#define RATE_I_SEP_ERR    60.0f    /* 允许积分消除约8.5度内的重心和推力静差 */
#define RATE_KP_INITIAL   0.64f
#define RATE_KI_INITIAL   0.25f    /* Slow trim only; avoid ground/hand-held windup. */
#define RATE_KD_INITIAL   0.25f    /* Avoid amplifying prop-guard and motor vibration. */
#define YAW_RATE_KP_INITIAL 0.90f
#define YAW_RATE_KI_INITIAL 0.15f
#define YAW_RATE_KD_INITIAL 0.00f
#define YAW_HOLD_KP          2.5f
#define YAW_HOLD_RATE_LIMIT 60.0f
#define GYRO_CAL_SAMPLES       800U
#define GYRO_CAL_MAX_TRIES    1200U
#define GYRO_CAL_STD_LIMIT     0.80f
#define GYRO_Z_DEADBAND_DPS    0.08f
#define FLOW_VEL_KP          0.0060f /* log89: brake velocity earlier so position recovery does not orbit the target */
#define FLOW_VEL_KI          0.0005f /* keep slow bias removal without building a launch oscillation */
#define FLOW_STALE_MS       250U /* bridge brief low-quality gaps, then suspend before stale flow can steer */
#define FLOW_ANGLE_LIMIT      0.9f /* moderate continuous authority around the held point */
#define FLOW_BRAKE_ANGLE_LIMIT 1.4f /* log91: 1.2deg stayed saturated for 37/68 samples with 0.7m residual error */
#define FLOW_BRAKE_MIN_QUALITY  60U
#define FLOW_BRAKE_MIN_SPEED_MM_S 100.0f /* react to motion before a large position error accumulates */
#define FLOW_BRAKE_MIN_POS_MM  40.0f
#define FLOW_POS_KP           0.12f /* log89: reduce the long position pull that carried recovery past the target */
#define FLOW_VEL_LIMIT      250.0f
#define FLOW_VEL_LPF_ALPHA    0.20f /* reject floor/line impulses before applying the stronger velocity brake */
#define FLOW_POS_LIMIT_MM  1500.0f /* retain the full error when visual drift exceeds the old 500mm clamp */
#define FLOW_CORR_SLEW_DEG    0.06f  /* prompt braking with filtered velocity, still no frame-to-frame angle step */
#define FLOW_LIMIT_SLEW_DEG   0.06f
#define FLOW_STICK_DEADBAND    0.35f
#define FLOW_ROLL_SIGN         1.0f /* hand test: body X+ is right; negative PID output commands left braking */
#define FLOW_PITCH_SIGN       -1.0f /* hand test: body Y- is forward; positive PID output must become back (-pitch) */
#define FLOW_RAW_LIMIT       1200.0f
#define FLOW_MIN_QUALITY       40U /* log82: retain useful 40-59 frames; still reject the 8-29 bursts */
#define FLOW_ENGAGE_MIN_PWM  1400.0f /* prepare just before the measured lift region */
#define FLOW_ENGAGE_MIN_MM    300.0f /* fallback when a ground reference has not yet been learned */
#define FLOW_TAKEOFF_RISE_MM   10.0f /* pre-brake on the first clear lift sample */
#define FLOW_RELEASE_MIN_MM     8.0f /* hysteresis keeps hold active through a small TOF bounce */
#define FLOW_ENGAGE_RAMP_MS    80U
#define FLOW_STABLE_TIME_MS    20U
#define FLOW_LEVEL_MAX_DEG      8.0f
#define FLOW_TAKEOFF_ANGLE_LIMIT 0.7f /* keep launch correction useful but subordinate to attitude stability */
#define FLOW_FULL_MAX_VZ_MM_S 120.0f
#define FLOW_FULL_MAX_ERR_MM  100.0f
#define FLOW_SUSPEND_DESCENT_MM_S (-180.0f) /* ascent is allowed; only a fast fall suspends flow */
#define FLOW_SUSPEND_SLEW_DEG    0.08f
#define FLOW_GYRO_MAX_DPS      20.0f
#define FLOW_GYRO_LPF_ALPHA     0.16f /* 200 Hz, approximately 6 Hz cutoff */
#define FLOW_SPEED_REJECT_MM_S 900.0f /* log44 measured real launch drift near 650-700 mm/s */
#define FLOW_STEP_REJECT_MM_S  500.0f
#define FLOW_REJECT_EXIT_COUNT  12U   /* retain the original point through a short burst */
#define FLOW_MANUAL_VEL_MAX_AGE_MS 180U /* retain momentum briefly across stick recenter */
#define DEG_TO_RAD_F            0.0174532925f
#define YAW_CONTROL_SIGN       1.0f

/* Thrust raises the real plant gain.  Soften only the fast P/D terms at high
 * throttle; keep I unchanged so the aircraft can still remove a static tilt.
 * The interpolation is continuous -- there is no gain step at either limit. */
#define RATE_SCHED_START_PWM 1400.0f
#define RATE_SCHED_END_PWM   1700.0f
#define RATE_P_HIGH_SCALE    0.82f
#define RATE_D_HIGH_SCALE    0.55f
#define TAKEOFF_GUARD_MIN_RISE_MM  15.0f
#define TAKEOFF_GUARD_MAX_RISE_MM 300.0f
#define TAKEOFF_GUARD_MIN_PWM     1450.0f
#define TAKEOFF_GUARD_ERROR_DEG     2.0f
#define TAKEOFF_GUARD_RECOVERY_DEG  8.0f
#define TAKEOFF_GUARD_ANGLE_P_SCALE 1.45f /* log42: actual pitch departed level by 4-9 deg at lift */
#define TAKEOFF_GUARD_RATE_P_SCALE  1.25f
#define TAKEOFF_GUARD_I_RAMP_MS     400U
#define RAMP_START        1000.0f  /* 斜坡起点: ESC idle, 电机不转 */
#define THROTTLE_TARGET   1300.0f  /* 提高悬停基础PWM；姿态修正会在此基础上产生差速 */
#define RAMP_TICKS        1600     /* 8秒内四路同步从1000线性增加到THROTTLE_TARGET */
#define STABILIZE_TICKS   200      /* 到达目标油门后保持1秒启动阶段 */
#define IMU_FAIL_LIMIT    5U       /* 连续5帧IMU读取失败（约25ms）才触发失效保护 */
#define IMU_FS_STOP_PWM   990.0f   /* ESC停止脉宽 */
#define IMU_FS_RAMP_STEP  3.0f     /* 每5ms降低3us：1550降至990约0.93秒 */
uint16_t startup_tick = 0;        /* 启动阶段计数 */

#define RC_CONTROL_WORK_PWM MOTOR_MIN /* official THR_CONTROL_WORK = THR_IDEL_OUTPUT = 1100 */
#define RC_INTEGRAL_START_PWM 1450.0f /* cage still supports the frame below the measured lift region */
#define RC_INTEGRAL_FULL_PWM  1600.0f /* add I smoothly after lift; never preload it on the ground */
#define MOTOR_TRIM_FULL_PWM    1450.0f /* takeoff trim reaches full value near measured lift throttle */
#define MOTOR_TRIM_FRONT_PWM      0.0f /* diagnostic flight: remove fixed front weight compensation */
#define MOTOR_TRIM_RIGHT_PWM     13.0f /* log53: cancel the remaining +X launch roll while keeping the correction conservative */
#define MOTOR_IDLE_RAMP_STEP  2.0f /* official-style 1000->1100 idle ramp in 0.25s */
#define RC_THROTTLE_RISE_STEP  2.0f /* 2us/5ms = 400us/s upward slew */
#define RC_THROTTLE_AIR_RISE_STEP 0.75f /* after lift: 150us/s, avoids another rapid climb */
#define RC_THROTTLE_FALL_STEP  4.0f /* faster commanded descent; failsafes bypass this */
#define RC_FLIGHT_TEST_MAX_PWM 1750.0f /* log84: 1650 clipped deliberate climb commands after lift-off */
#define IMU_STALE_LIMIT_MS 75U /* stale main-loop IMU data triggers smooth shutdown */
#define ALT_HOLD_AUX_CHANNEL       4U    /* CH5: high=altitude hold */
#define ALT_HOLD_AUX_ON_US      1700U
#define ALT_HOLD_AUX_OFF_US     1300U
#define ALT_HOLD_STICK_CENTER   1500.0f
#define ALT_HOLD_STICK_DEADBAND   20.0f
#define ALT_HOLD_ENGAGE_LOW     1400.0f
#define ALT_HOLD_ENGAGE_HIGH    1660.0f
#define ALT_HOLD_MAX_CLIMB_MM_S  450.0f
#define ALT_HOLD_MIN_MM           80.0f /* allow low hover when a learned ground reference is available */
#define ALT_HOLD_MAX_MM         1700.0f
#define ALT_HOLD_STALE_MS        300U
#define ALT_HOLD_VZ_KD             0.075f /* log91: add moderate damping to the recurring 300-580mm height cycle */
#define ALT_HOLD_CORR_LIMIT        45.0f /* log90: remove the delayed +60us recovery that pumped height */
#define ALT_HOLD_PWM_SLEW_UP_STEP   0.50f
#define ALT_HOLD_PWM_SLEW_DOWN_STEP 0.50f
#define ALT_HOLD_ASCENT_SLEW_DOWN_STEP 1.00f
#define ALT_HOLD_FAST_CATCH_STEP     0.75f
#define ALT_HOLD_HOVER_PWM_MAX    1660.0f /* preserve actual hand-over throttle within hold range */
#define ALT_HOLD_OUTPUT_DROP_US     22.0f
#define ALT_HOLD_ASCENT_DROP_US     35.0f
#define ALT_HOLD_OUTPUT_RISE_US     45.0f /* enough steady authority to climb back after a large height loss */
#define ALT_HOLD_CAPTURE_VZ_PWM_GAIN 0.02f /* do not underestimate hover PWM after a gentle rising capture */
#define ALT_HOLD_CAPTURE_BIAS_MAX_US  8.0f
#define ALT_HOLD_HOVER_LEARN_ERR_GAIN 0.00030f /* log91: correct the persistent 65-75mm low bias without a catch pulse */
#define ALT_HOLD_HOVER_LEARN_VZ_GAIN  0.00035f
#define ALT_HOLD_HOVER_LEARN_STEP     0.05f
#define ALT_HOLD_HOVER_LEARN_ERR_MM 150.0f
#define ALT_HOLD_HOVER_LEARN_VZ_MM_S 60.0f
#define ALT_HOLD_ASCENT_BRAKE_VZ   150.0f
#define ALT_HOLD_ASCENT_BRAKE_ERR  100.0f
#define ALT_HOLD_FAST_DESCENT_VZ  (-180.0f)
#define ALT_HOLD_VZ_RAW_LIMIT      600.0f
#define ALT_HOLD_VZ_LPF_ALPHA        0.18f /* smooth TOF velocity while keeping enough response for descent arrest */
#define ALT_AUTO_TAKEOFF_RISE_MM    40.0f /* low test flight: capture after a real 4 cm rise */
#define ALT_HOLD_AIRBORNE_RISE_MM   40.0f /* match request and controller engagement thresholds */
#define ALT_AUTO_STABLE_MS         450U /* log82 follow-up: distinguish a truly released CH3 from a slow push */
#define ALT_AUTO_STABLE_CHANGE_US    6U /* reset settling on small cumulative motion while tolerating 1-2us jitter */
#define ALT_AUTO_CAPTURE_MAX_VZ_MM_S 120.0f
#define ALT_AUTO_VZ_STABLE_MS       200U
#define ALT_PRECAPTURE_ASCENT_BRAKE_MAX_US 60.0f
#define ALT_PRECAPTURE_DESCENT_BOOST_MAX_US 12.0f
#define ALT_PRECAPTURE_VZ_GAIN       0.18f
#define ALT_PRECAPTURE_PWM_STEP      1.00f
#define ALT_AUTO_RELEASE_CHANGE_US  25U /* log84: the pilot's 35us climb input must release automatic hold */
#define ALT_AUTO_RELEASE_CONFIRM_MS  80U
#define EMERGENCY_LAND_AUX_CHANNEL   5U    /* CH6 high starts a latched landing */
#define EMERGENCY_LAND_AUX_ON_US  1700U
#define SAFETY_CEILING_RISE_MM     1200.0f /* log85: 600mm repeatedly interrupted ordinary low test flights */
#define SAFETY_CEILING_CONFIRM_SAMPLES 3U
#define SAFETY_CEILING_OVERRIDE_PWM 1300.0f /* low CH3 always gives control back to the pilot */
#define AUTOLAND_DESCENT_MM_S       120.0f
#define AUTOLAND_FLARE_HEIGHT_MM    150.0f
#define AUTOLAND_FLARE_MM_S          60.0f
#define AUTOLAND_TOUCHDOWN_MM        35.0f
#define AUTOLAND_TOUCHDOWN_SAMPLES    6U
#define AUTOLAND_MAX_TIME_MS      15000U
#define AUTOLAND_SENSOR_STALE_MS    400U
#define AUTOLAND_HOVER_PWM_MAX     1660.0f /* inherit the learned real hover throttle */
#define AUTOLAND_PWM_RISE_US_S       300.0f /* arrest an excessive descent before ground impact */
#define AUTOLAND_PWM_FALL_US_S        50.0f
#define AUTOLAND_ASCENT_FALL_US_S     80.0f
#define AUTOLAND_OUTPUT_DROP_US       40.0f
#define AUTOLAND_OUTPUT_RISE_US       60.0f
#define AUTOLAND_CORR_LIMIT            60.0f
#define AUTOLAND_ASCENT_MM_S         100.0f
#define AUTOLAND_FALLBACK_STEP        0.25f
#define AUTOLAND_TOUCHDOWN_RAMP_STEP  2.0f
#undef THROTTLE_TARGET
#define THROTTLE_TARGET throttle_slewed_cmd
#undef RAMP_TICKS
#define RAMP_TICKS 1U

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
static void FlowHold_Update(float roll_command_deg, float pitch_command_deg,
                            float throttle_us);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* 固定角度P：取消旧版随倾角从5增加到11的非线性增益。 */
static float Attitude_Update_Outer(PID_t *pid, float target, float angle, float dt)
{
    return PID_Update_Outer(pid, target, angle, dt);
}

/* 低通滤波器不能从全0状态启动，否则加速度/姿态会额外花一段时间收敛。 */
static void Filter_Seed(filter_buffer *buf, float value)
{
    uint8_t i;
    for (i = 0; i < 3; i++) {
        buf->input[i] = value;
        buf->output[i] = value;
    }
}

/* 整体平移油门后仍可完整保留差速；只有姿态请求跨度超过可用PWM范围，
 * 才属于真正的执行器饱和并触发抗积分。 */
static uint8_t Mixer_Would_Saturate(const Mixer_t *m, float lower_limit)
{
    float raw1 = m->throttle - m->pitch_out + m->roll_out - m->yaw_out;
    float raw2 = m->throttle - m->pitch_out - m->roll_out + m->yaw_out;
    /* Yaw acts on diagonal motor pairs: LF+RR versus RF+LR. */
    float raw3 = m->throttle + m->pitch_out - m->roll_out - m->yaw_out;
    float raw4 = m->throttle + m->pitch_out + m->roll_out + m->yaw_out;
    float raw_min = raw1;
    float raw_max = raw1;
    if (raw2 < raw_min) raw_min = raw2;
    if (raw3 < raw_min) raw_min = raw3;
    if (raw4 < raw_min) raw_min = raw4;
    if (raw2 > raw_max) raw_max = raw2;
    if (raw3 > raw_max) raw_max = raw3;
    if (raw4 > raw_max) raw_max = raw4;
    return (raw_max - raw_min) > (MOTOR_MAX - lower_limit);
}

/* 启动斜坡专用混控。允许PWM低于正常飞行MOTOR_MIN，但仍保留姿态差速，
 * 避免电机已经起转时四路输出却完全相同。 */
static void Startup_Mixer_Output(Mixer_t *m)
{
    float lower_limit = (m->throttle < MOTOR_MIN) ? RAMP_START : MOTOR_MIN;
    Mixer_Update_Limited(m, lower_limit);

    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, (uint16_t)m->m1);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, (uint16_t)m->m2);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, (uint16_t)m->m3);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, (uint16_t)m->m4);
}

/* IMU连续失效后不再保留旧的姿态差速：四电机统一为失效前平均推力，
 * 再平滑降至停止脉宽。该状态锁存，必须重新上电并发送OK后才会再次起飞。 */
static void IMU_Failsafe_Output(void)
{
    if (imu_failsafe_pwm > IMU_FS_STOP_PWM + IMU_FS_RAMP_STEP) {
        imu_failsafe_pwm -= IMU_FS_RAMP_STEP;
    } else {
        imu_failsafe_pwm = IMU_FS_STOP_PWM;
    }

    mixer.m1 = imu_failsafe_pwm;
    mixer.m2 = imu_failsafe_pwm;
    mixer.m3 = imu_failsafe_pwm;
    mixer.m4 = imu_failsafe_pwm;
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, (uint16_t)imu_failsafe_pwm);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, (uint16_t)imu_failsafe_pwm);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, (uint16_t)imu_failsafe_pwm);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, (uint16_t)imu_failsafe_pwm);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* SystemClock_Config会重设SysTick优先级；必须在其后设为最高，
   * 才能让TIM3中断内HAL_I2C的2ms超时计数继续走。 */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
	/* Switch USART1 to pure binary mode before the first printf.  fputc will
	 * discard text while NCLink sends official ground-station frames directly. */
	usart1_binary_mode = ENABLE_NCLINK;
	{
		uint8_t tof_init = MS53L0_Init();
		printf("MS53L0 init: %s (ret=%u ready=%u profile=UM2039-7.2 budget=33ms I2C=400kHz)\r\n",
		       (tof_init == 0U) ? "OK" : "FAIL",
		       (unsigned int)tof_init,
		       (unsigned int)ms53l0_ready);
	}
	#if ENABLE_OPTICAL_FLOW
	OpticalFlow_Init();
  printf("LC306 optical-flow enabled\r\n");
	#else
  HAL_NVIC_DisableIRQ(USART2_IRQn);
  printf("Optical Flow RX disabled during attitude tuning\r\n");
	#endif

	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 990);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 990);
	
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 990);
	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 990);
	HAL_Delay(5000);
	printf("ESC unlock done\r\n");

  uint8_t st = BMI088_Init(&hi2c1);
  if (st == 0)
      printf("BMI088 init OK\r\n");
  else {
      printf("BMI088 init FAIL: %d\r\n", st);
      while (1);
  }

  printf("Gyro calibrating... keep still\r\n");
  HAL_Delay(1500);  /* 先让陀螺仪温度和输出稳定，再计算零偏。 */
  for (uint8_t cal_pass = 0U; cal_pass < 2U; cal_pass++) {
    float sx = 0.0f, sy = 0.0f, sz = 0.0f;
    float sx2 = 0.0f, sy2 = 0.0f, sz2 = 0.0f;
    uint32_t valid = 0U;
    uint32_t tries = 0U;
    while (valid < GYRO_CAL_SAMPLES && tries < GYRO_CAL_MAX_TRIES) {
      tries++;
      if (BMI088_ReadAll(&hi2c1, &imu) == HAL_OK) {
        sx += imu.gx;  sy += imu.gy;  sz += imu.gz;
        sx2 += imu.gx * imu.gx;
        sy2 += imu.gy * imu.gy;
        sz2 += imu.gz * imu.gz;
        valid++;
      }
      HAL_Delay(5); /* 与BMI088的200Hz ODR同步，避免重复统计同一帧。 */
    }
    if (valid == 0U) {
      printf("Gyro calibration FAIL: no valid sample\r\n");
      gx_off = gy_off = gz_off = 0.0f;
      break;
    }

    float inv_n = 1.0f / (float)valid;
    float mx = sx * inv_n;
    float my = sy * inv_n;
    float mz = sz * inv_n;
    float std_x = sqrtf(fmaxf(0.0f, sx2 * inv_n - mx * mx));
    float std_y = sqrtf(fmaxf(0.0f, sy2 * inv_n - my * my));
    float std_z = sqrtf(fmaxf(0.0f, sz2 * inv_n - mz * mz));
    gx_off = mx;
    gy_off = my;
    gz_off = mz;

    if (std_x <= GYRO_CAL_STD_LIMIT &&
        std_y <= GYRO_CAL_STD_LIMIT &&
        std_z <= GYRO_CAL_STD_LIMIT) {
      printf("Gyro zero OK: n=%lu std=%.2f,%.2f,%.2f\r\n",
             (unsigned long)valid, std_x, std_y, std_z);
      break;
    }
    printf("Gyro moved: std=%.2f,%.2f,%.2f, retry keep still\r\n",
           std_x, std_y, std_z);
    HAL_Delay(1000);
  }
  printf("Gyro offset: %.3f, %.3f, %.3f (Z zero applied)\r\n",
         gx_off, gy_off, gz_off);
  #define SAMPLE_FREQ   200.0f
  #define D_CUTOFF_FREQ 12.0f
  #define IMU_CUTOFF_FREQ 12.0f
  /* 桨保会引入柔性振动，降低软件低通带宽，避免振动进入P/D项。 */
  set_cutoff_frequency(SAMPLE_FREQ, IMU_CUTOFF_FREQ, &accel_lpf_param);
  set_cutoff_frequency(SAMPLE_FREQ, IMU_CUTOFF_FREQ, &gyro_lpf_param);

  /* 用当前重力方向直接初始化姿态和滤波器。旧代码固定从0度开始，
   * 当开机时机体已有倾角，互补滤波需要约0.5秒才显示真实角度。 */
  if (BMI088_ReadAll(&hi2c1, &imu) == HAL_OK) {
    BMI088_Data_t imu_init_raw = imu;
    imu.gx -= gx_off;
    imu.gy -= gy_off;
    imu.gz -= gz_off;
    Filter_Seed(&accel_lpf_buf[0], imu.ax);
    Filter_Seed(&accel_lpf_buf[1], imu.ay);
    Filter_Seed(&accel_lpf_buf[2], imu.az);
    Filter_Seed(&gyro_lpf_buf[0], imu.gx);
    Filter_Seed(&gyro_lpf_buf[1], imu.gy);
    Filter_Seed(&gyro_lpf_buf[2], imu.gz);
    pitch = atan2f(imu.ay, sqrtf(imu.ax * imu.ax + imu.az * imu.az)) * 57.2958f;
    roll  = atan2f(imu.ax, sqrtf(imu.ay * imu.ay + imu.az * imu.az)) * 57.2958f;
    printf("Attitude init raw: pitch=%.2f roll=%.2f | frame level ref: pitch=%.2f roll=%.2f | corrected: pitch=%.2f roll=%.2f\r\n",
           pitch, roll, level_pitch_ref_deg, level_roll_ref_deg,
           pitch - level_pitch_ref_deg, roll - level_roll_ref_deg);
    /* 控制循环会自行减去零偏，因此缓存必须保存未经补偿的原始值。 */
    imu_latest_raw = imu_init_raw;
    imu_latest_ms = HAL_GetTick();
    imu_latest_seq = 1U;
  }

  /* 保留官方角度环响应。I项需要足以消除四电机推力静差，
   * D项只提供必要阻尼，避免在接近平衡点时过度“刹车”。 */
  PID_Init_Outer(&pid_pitch,      ANGLE_KP_FIXED, 0.0f, 0.0f, 30.0f, 100.0f, 500.0f);
  PID_Init_Outer(&pid_roll,       ANGLE_KP_FIXED, 0.0f, 0.0f, 30.0f, 100.0f, 500.0f);
	PID_Init_Outer(&pid_height,
    0.065f,   /* log91: soften position demand while velocity damping arrests the cycle */
    0.014f,   /* let slow hover learning carry steady load instead of integral pumping */
    0.0f,     /* vertical-speed damping is applied separately */
    500.0f,   /* err_max: 偏差超过500mm限幅 */
    80.0f,    /* integral contribution limit */
    ALT_HOLD_CORR_LIMIT);
  pid_height.integrate_separation_flag = 1U;
  pid_height.err_max = 500.0f;
  pid_height.integrate_max = 15.0f;
  pid_height.integrate_separation_err = 150.0f;
  PID_Init_Inner(&pid_pitch_rate, RATE_KP_INITIAL, RATE_KI_INITIAL, RATE_KD_INITIAL,
                 600.0f, 45.0f, 400.0f,
                 SAMPLE_FREQ, D_CUTOFF_FREQ);
  PID_Init_Inner(&pid_roll_rate,  RATE_KP_INITIAL, RATE_KI_INITIAL, RATE_KD_INITIAL,
                 600.0f, 45.0f, 400.0f,
                 SAMPLE_FREQ, D_CUTOFF_FREQ);
  PID_Init_Inner(&pid_yaw_rate, YAW_RATE_KP_INITIAL, YAW_RATE_KI_INITIAL,
                 YAW_RATE_KD_INITIAL, 300.0f, 30.0f, 150.0f,
                 SAMPLE_FREQ, D_CUTOFF_FREQ);
  PID_Init_Outer(&pid_flow_x, FLOW_VEL_KP, FLOW_VEL_KI, 0.0f,
                 500.0f, 1.5f, FLOW_ANGLE_LIMIT);
  PID_Init_Outer(&pid_flow_y, FLOW_VEL_KP, FLOW_VEL_KI, 0.0f,
                 500.0f, 1.5f, FLOW_ANGLE_LIMIT);
  pid_pitch_rate.integrate_separation_flag = 1;
  pid_pitch_rate.integrate_separation_err = RATE_I_SEP_ERR;
  pid_roll_rate.integrate_separation_flag = 1;
  pid_roll_rate.integrate_separation_err = RATE_I_SEP_ERR;
  pid_yaw_rate.integrate_separation_flag = 1;
  pid_yaw_rate.integrate_separation_err = 80.0f;
  YaoKong_Init();
  if (ENABLE_NCLINK) {
    NCLink_Init(&huart1);
  }
  /* PPM must preempt the 200Hz attitude loop; official MaplePilot uses
   * preemption priority 0 for its PPM EXTI.  Keep this override in main.c's
   * USER CODE area so a future CubeMX generation cannot remove the fix. */
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0U, 0U);
  __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_9);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
  mixer.throttle  = MOTOR_MIN;
  mixer.pitch_out = 0;
  mixer.roll_out  = 0;
  mixer.yaw_out   = 0;
  mixer.m1 = 990.0f;
  mixer.m2 = 990.0f;
  mixer.m3 = 990.0f;
  mixer.m4 = 990.0f;

  if (debug_mode) {
    printf("DEBUG MODE: motors stopped, IMU in main loop\r\n");
  } else {
    printf("DISARMED: official PPM on PD9, throttle low + CH4 high 2s to arm\r\n");
  }
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  uint8_t control_loop_started = 0U;
  /* Keep the receiver snapshot out of the shared main/interrupt MSP stack.
   * TIM3, PPM and SysTick can nest while main is inside printf/I2C. */
  static YaoKong_State_t remote;
  while (1)
  {
    uint32_t target_update_primask;
    static uint32_t flow_parse_count = 0U;
    static uint32_t flow_parse_bytes = 0U;

    YaoKong_Process();
    YaoKong_GetSnapshot(&remote);

    /* Keep blocking HAL I2C outside the 200Hz control interrupt. If this read
     * or printf ever stalls, TIM3 still runs and detects stale IMU data. */
    static uint32_t imu_poll_tick = 0U;
    if (control_loop_started &&
        (uint32_t)(HAL_GetTick() - imu_poll_tick) >= 5U) {
      BMI088_Data_t sample;
      uint32_t sample_tick = HAL_GetTick();
      if (BMI088_ReadAll(&hi2c1, &sample) == HAL_OK) {
        uint32_t imu_copy_primask = __get_PRIMASK();
        __disable_irq();
        imu_latest_raw = sample;
        imu_latest_ms = sample_tick;
        imu_latest_seq++;
        if (imu_copy_primask == 0U) __enable_irq();
      } else {
        imu_bus_read_fail++;
      }
      imu_poll_tick = sample_tick;
    }
		static uint32_t tof_tick = 0U;
        static uint32_t tof_poll_tick = 0U;
        uint16_t tof_async_raw = 0xFFFFU;
        uint8_t tof_async_state = MS53L0_ASYNC_WAIT;

        /* A 2 ms poll interval is much faster than the sensor's 33 ms timing
         * budget without flooding I2C2 with readiness-register reads. */
        if (MS53L0_MeasurementActive() &&
            (uint32_t)(HAL_GetTick() - tof_poll_tick) >= 2U) {
          tof_poll_tick = HAL_GetTick();
          tof_async_state = MS53L0_PollMeasurement(&tof_async_raw);
        }

        /* Start at 20 Hz, but never wait here for the 33 ms measurement.
         * BMI088 polling at the top of the loop therefore remains at 200 Hz. */
        if (!MS53L0_MeasurementActive() &&
            (uint32_t)(HAL_GetTick() - tof_tick) >= 50U) {
          if (!MS53L0_RequestMeasurement()) {
				tof_timeout_cnt++;
				tof_height_valid = 0U;
          }
          tof_tick = HAL_GetTick();
        }

		if (tof_async_state == MS53L0_ASYNC_READY ||
            tof_async_state == MS53L0_ASYNC_ERROR)
			{
				uint16_t raw = (tof_async_state == MS53L0_ASYNC_READY)
                             ? tof_async_raw : 0xFFFFU;
				tof_read_cnt++;
				tof_raw_mm = raw;
				if (raw == 0xFFFF || raw < 30 || raw > 2000)
					{
						tof_timeout_cnt++;
						tof_height_valid = 0;
					} 
				else
					{
						
						/* 关键：倾斜修正。飞机的TOF是斜射到地面的，不是垂直距离 */
						float cos_pitch = cosf(pitch * 0.0174533f);  // 度转弧度
						float cos_roll  = cosf(roll  * 0.0174533f);
						float corrected_h = (float)raw * cos_pitch * cos_roll;
						
						/* 一阶低通，平滑TOF噪声 */
						if (height_lpf < 1.0f)
							{
								height_lpf = corrected_h;  // 首次直接赋值
							} 
						else
							{
								height_lpf = 0.8f * height_lpf + 0.2f * corrected_h;
							}
						tof_height_mm = height_lpf;
						{
							uint32_t height_now_ms = HAL_GetTick();
							if (tof_vz_last_ms != 0U) {
								float height_dt = (float)(height_now_ms - tof_vz_last_ms) * 0.001f;
								if (height_dt >= 0.02f && height_dt <= 0.20f) {
									float raw_vz = (height_lpf - tof_vz_last_height_mm) / height_dt;
									raw_vz = constrain_float(raw_vz, -ALT_HOLD_VZ_RAW_LIMIT,
									                         ALT_HOLD_VZ_RAW_LIMIT);
									tof_vz_est_mm_s = 0.85f * tof_vz_est_mm_s + 0.15f * raw_vz;
								}
							} else {
								tof_vz_est_mm_s = 0.0f;
							}
							tof_vz_last_height_mm = height_lpf;
							tof_vz_last_ms = height_now_ms;
						}
						tof_height_valid = 1;
						tof_last_valid_ms = HAL_GetTick();
						tof_update_seq++;
				}
			}
    #if ENABLE_OPTICAL_FLOW
    /* Use the original, previously verified driver only for acquisition.
     * No optical-flow correction is allowed in debug mode. */
    /* Parse once per newly received frame. The legacy parser keeps frames in
     * its window, so calling it every main-loop pass reuses the same sample. */
    if ((uint32_t)(raw_byte_cnt - flow_parse_bytes) >= 14U) {
      flow_parse_bytes = raw_byte_cnt;
      if (Optflow_Prase()) {
        uint16_t flow_dt_us = opt_origin_data.integration_timespan;
        flow_parse_count++;
        if (flow_dt_us >= 10000U && flow_dt_us <= 50000U &&
            opt_origin_data.qual >= FLOW_MIN_QUALITY &&
            FastAbs((float)opt_origin_data.pixel_flow_x_integral) <= FLOW_RAW_LIMIT &&
            FastAbs((float)opt_origin_data.pixel_flow_y_integral) <= FLOW_RAW_LIMIT) {
          flow_last_sample_ms = HAL_GetTick();
          flow_sample_seq++;
        }
      }
    }
    #endif

    /* Learn only the optical-flow ground reference while disarmed.  This is
     * not used to gate attitude PID; it only lets point hold recognise an
     * 8 mm real lift even when the sensor installation height is 70-100 mm. */
    if (!remote.armed && tof_height_valid &&
        tof_height_mm > 30.0f && tof_height_mm < 300.0f) {
      if (!flow_ground_height_valid) {
        flow_ground_height_mm = tof_height_mm;
        flow_ground_height_valid = 1U;
      } else {
        flow_ground_height_mm = 0.95f * flow_ground_height_mm +
                                0.05f * tof_height_mm;
      }
    }

    if (!debug_mode && !control_loop_started && remote.armed && !remote.failsafe) {
      /* 收到OK后才从零开始斜坡，避免串口中途连接导致复位后直接起转。 */
      startup_tick = 0U;
      throttle_slewed_cmd = RAMP_START;
      motor_idle_ramp_pwm = RAMP_START;
      motor_idle_ramp_active = 1U;
      yaw = 0.0f;
      yaw_heading_target_deg = 0.0f;
      yaw_hold_rate_debug = 0.0f;
      pid_pitch_rate.integrate = 0.0f;
      pid_roll_rate.integrate = 0.0f;
      PID_Reset(&pid_yaw_rate);
      PID_Reset(&pid_flow_x);
      PID_Reset(&pid_flow_y);
      flow_roll_correction_deg = 0.0f;
      flow_pitch_correction_deg = 0.0f;
      flow_hold_active = 0U;
      flow_hold_effective = 0U;
      flow_velocity_seeded_debug = 0U;
      flow_hold_request_cmd = 0U;
      flow_hold_fault = 0U;
      alt_hold_enabled = 0U;
      alt_hold_fault = 0U;
      alt_hold_request_cmd = 0U;
      alt_hold_switch_request_cmd = 0U;
      alt_hold_auto_latched = 0U;
      alt_hold_recenter_cmd = 0U;
      alt_hold_capture_settle_debug = 0U;
      alt_hold_stick_center_pwm = ALT_HOLD_STICK_CENTER;
      alt_auto_stable_anchor_us = remote.channel[YAOKONG_CH_THROTTLE];
      alt_auto_last_move_ms = HAL_GetTick();
      alt_auto_release_since_ms = 0U;
      alt_auto_vz_stable_since_ms = 0U;
      alt_auto_stable_capture_done = 0U;
      alt_auto_airborne_seen = 0U;
      PID_Reset(&pid_height);
      imu_consecutive_fail = 0U;
      imu_failsafe_active = 0U;
      rc_failsafe_active = 0U;
      imu_failsafe_pwm = IMU_FS_STOP_PWM;
      auto_land_active = 0U;
      auto_land_complete = 0U;
      auto_land_reason = 0U;
      ceiling_land_pilot_override = 0U;
      auto_land_state = 0U;
      auto_land_target_mm = 0.0f;
      auto_land_output_pwm = IMU_FS_STOP_PWM;
      auto_land_relative_mm = 0.0f;
      auto_land_vz_mm_s = 0.0f;
      imu_latest_ms = HAL_GetTick();
      CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
      DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
      HAL_TIM_Base_Start_IT(&htim3);
      control_loop_started = 1U;
      printf("Control loop started (200Hz TIM3 interrupt)\r\n");
      printf("PPM ARMED: motors ramp 1000->1100 idle, then CH3 controls throttle\r\n");
      printf("MODE: left CH3=manual throttle, CH4=arm/lock; right CH1/CH2=direction\r\n");
      printf("RC CH1=roll CH2=pitch CH3=throttle CH4=arm/lock, max tilt=%.1fdeg\r\n",
             YAOKONG_MAX_TILT_DEG);
      printf("ALT HOLD: capture 450ms/6us, release on 25us CH3 move\r\n");
      printf("ALT CAPTURE: +45us damped recovery, slow hover-bias learning\r\n");
      printf("EMERGENCY LAND: learned hover PWM, 120mm/s descent, fast catch\r\n");
      printf("SAFETY CEILING: 1200mm above learned ground\r\n");
      printf("POINT HOLD: damped cascade; 0.7/0.9deg hold, 1.4deg brake\r\n");
      printf("TAKEOFF GUARD: feedback boost below 300mm, no fixed angle bias\r\n");
    }
    /* 两个目标必须作为一组更新，防止200Hz中断读到一新一旧。 */
    /* Loss of complete PPM frames while armed is latched.  Keep the IMU
     * attitude loop alive and land with TOF instead of removing all motor
     * differential and blindly ramping four equal outputs to zero. */
    if (control_loop_started && remote.failsafe && !rc_failsafe_active) {
      target_update_primask = __get_PRIMASK();
      __disable_irq();
      rc_failsafe_active = 1U;
      auto_land_active = 1U;
      auto_land_reason = 2U;
      if (target_update_primask == 0U) __enable_irq();
      printf("RC FAILSAFE: PPM lost, automatic landing latched\r\n");
    }

    /* yaokong.c returns control only after 30 consecutive complete PPM frames
     * with centred attitude sticks.  Cancel only an unfinished RC-loss landing
     * and hand throttle back from the current landing output without a step. */
    if (control_loop_started && rc_failsafe_active && !remote.failsafe &&
        remote.connected && remote.armed && auto_land_active &&
        auto_land_reason == 2U && !auto_land_complete) {
      target_update_primask = __get_PRIMASK();
      __disable_irq();
      throttle_slewed_cmd = auto_land_output_pwm;
      mixer.throttle = auto_land_output_pwm;
      alt_hold_output_pwm = auto_land_output_pwm;
      rc_failsafe_active = 0U;
      auto_land_active = 0U;
      auto_land_reason = 0U;
      auto_land_state = 0U;
      if (target_update_primask == 0U) __enable_irq();
      printf("RC RECOVERED: stable PPM, manual control restored\r\n");
    }

    if (control_loop_started && remote.armed && !auto_land_active &&
        !remote.failsafe &&
        remote.channel[EMERGENCY_LAND_AUX_CHANNEL] >= EMERGENCY_LAND_AUX_ON_US) {
      target_update_primask = __get_PRIMASK();
      __disable_irq();
      auto_land_active = 1U;
      auto_land_reason = 1U;
      if (target_update_primask == 0U) __enable_irq();
      printf("EMERGENCY LAND: CH6 switch, automatic landing latched\r\n");
    }

    /* The disarm gesture is accepted only at low throttle in yaokong.c. */
    if (control_loop_started && !remote.armed && !remote.failsafe) {
      HAL_TIM_Base_Stop_IT(&htim3);
      __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 990U);
      __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 990U);
      __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 990U);
      __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 990U);
      mixer.m1 = mixer.m2 = mixer.m3 = mixer.m4 = 990.0f;
      mixer.throttle = RAMP_START;
      throttle_slewed_cmd = RAMP_START;
      motor_idle_ramp_pwm = RAMP_START;
      motor_idle_ramp_active = 0U;
      yaw = 0.0f;
      yaw_heading_target_deg = 0.0f;
      yaw_hold_rate_debug = 0.0f;
      PID_Reset(&pid_yaw_rate);
      PID_Reset(&pid_flow_x);
      PID_Reset(&pid_flow_y);
      flow_roll_correction_deg = 0.0f;
      flow_pitch_correction_deg = 0.0f;
      flow_hold_active = 0U;
      flow_hold_effective = 0U;
      flow_velocity_seeded_debug = 0U;
      flow_hold_request_cmd = 0U;
      flow_hold_fault = 0U;
      alt_hold_enabled = 0U;
      alt_hold_request_cmd = 0U;
      alt_hold_switch_request_cmd = 0U;
      alt_hold_auto_latched = 0U;
      alt_hold_recenter_cmd = 0U;
      alt_hold_capture_settle_debug = 0U;
      alt_hold_stick_center_pwm = ALT_HOLD_STICK_CENTER;
      alt_auto_stable_anchor_us = 1000U;
      alt_auto_last_move_ms = HAL_GetTick();
      alt_auto_release_since_ms = 0U;
      alt_auto_vz_stable_since_ms = 0U;
      alt_auto_stable_capture_done = 0U;
      alt_auto_airborne_seen = 0U;
      PID_Reset(&pid_height);
      auto_land_active = 0U;
      auto_land_complete = 0U;
      auto_land_reason = 0U;
      ceiling_land_pilot_override = 0U;
      auto_land_state = 0U;
      auto_land_target_mm = 0.0f;
      auto_land_output_pwm = IMU_FS_STOP_PWM;
      auto_land_relative_mm = 0.0f;
      auto_land_vz_mm_s = 0.0f;
      control_loop_started = 0U;
      printf("PPM DISARMED: motors stopped\r\n");
    }

    target_update_primask = __get_PRIMASK();
    __disable_irq();
    pitch_target_cmd = (remote.armed && !auto_land_active) ? remote.pitch_target_deg : 0.0f;
    roll_target_cmd = (remote.armed && !auto_land_active) ? remote.roll_target_deg : 0.0f;
    throttle_target_cmd = remote.armed ? (float)remote.throttle_us : RAMP_START;
    yaw_rate_target_cmd = (remote.armed && !auto_land_active) ? remote.yaw_rate_target_dps : 0.0f;
    if (target_update_primask == 0U) {
      __enable_irq();
    }

    /* CH5 is an explicit height lock and ignores CH3 while it is high.
     * With CH5 low, a stable airborne CH3 automatically captures height.
     * A small displacement around the captured centre can trim the height
     * target, while a deliberate 45 us move promptly restores direct throttle. */
    if (!remote.armed || remote.failsafe || auto_land_active) {
      alt_hold_request_cmd = 0U;
      alt_hold_switch_request_cmd = 0U;
      alt_auto_vz_stable_since_ms = 0U;
      alt_hold_capture_settle_debug = 0U;
    } else {
      uint16_t throttle_now = remote.channel[YAOKONG_CH_THROTTLE];
      uint16_t throttle_change = (throttle_now >= alt_auto_stable_anchor_us)
                               ? (throttle_now - alt_auto_stable_anchor_us)
                               : (alt_auto_stable_anchor_us - throttle_now);
      uint32_t now_ms = HAL_GetTick();
      uint8_t height_fresh = tof_last_valid_ms != 0U &&
                             (uint32_t)(now_ms - tof_last_valid_ms) <= ALT_HOLD_STALE_MS;
      uint8_t airborne = height_fresh && flow_ground_height_valid &&
                         tof_height_mm >= flow_ground_height_mm + ALT_AUTO_TAKEOFF_RISE_MM;
      uint8_t vertical_capture_ready = height_fresh &&
          FastAbs(tof_vz_est_mm_s) <= ALT_AUTO_CAPTURE_MAX_VZ_MM_S;
      alt_hold_capture_settle_debug = 0U;

      if (remote.channel[ALT_HOLD_AUX_CHANNEL] >= ALT_HOLD_AUX_ON_US)
        alt_hold_switch_request_cmd = 1U;
      else if (remote.channel[ALT_HOLD_AUX_CHANNEL] <= ALT_HOLD_AUX_OFF_US)
        alt_hold_switch_request_cmd = 0U;

      if (alt_hold_auto_latched) {
        if (throttle_change >= ALT_AUTO_RELEASE_CHANGE_US) {
          if (alt_auto_release_since_ms == 0U)
            alt_auto_release_since_ms = now_ms;
          else if ((uint32_t)(now_ms - alt_auto_release_since_ms) >=
                   ALT_AUTO_RELEASE_CONFIRM_MS) {
            alt_hold_auto_latched = 0U;
            alt_auto_stable_capture_done = 0U;
            alt_auto_stable_anchor_us = throttle_now;
            alt_auto_last_move_ms = now_ms;
            alt_auto_release_since_ms = 0U;
            alt_auto_vz_stable_since_ms = 0U;
          }
        } else {
          alt_auto_release_since_ms = 0U;
        }
      } else if (throttle_change >= ALT_AUTO_STABLE_CHANGE_US) {
        alt_auto_stable_anchor_us = throttle_now;
        alt_auto_last_move_ms = now_ms;
        alt_auto_stable_capture_done = 0U;
        alt_auto_release_since_ms = 0U;
        alt_auto_vz_stable_since_ms = 0U;
      }
      if (airborne && !alt_auto_airborne_seen) {
        alt_auto_airborne_seen = 1U;
        alt_auto_last_move_ms = now_ms;
        alt_auto_stable_capture_done = 0U;
        alt_auto_vz_stable_since_ms = 0U;
      }
      if (!alt_hold_auto_latched && airborne && vertical_capture_ready) {
        if (alt_auto_vz_stable_since_ms == 0U)
          alt_auto_vz_stable_since_ms = now_ms;
      } else if (!alt_hold_auto_latched) {
        alt_auto_vz_stable_since_ms = 0U;
      }
      /* Do not arm the automatic latch behind an active CH5 lock.  Releasing
       * CH5 gives manual throttle first, then auto-captures if
       * the pilot leaves CH3 unchanged. */
      if (alt_hold_switch_request_cmd) {
        alt_hold_auto_latched = 0U;
        alt_auto_release_since_ms = 0U;
        alt_auto_stable_anchor_us = throttle_now;
        alt_auto_last_move_ms = now_ms;
        alt_auto_stable_capture_done = 0U;
        alt_auto_vz_stable_since_ms = 0U;
      } else if (airborne &&
          !alt_auto_stable_capture_done &&
          (uint32_t)(now_ms - alt_auto_last_move_ms) >= ALT_AUTO_STABLE_MS &&
          alt_auto_vz_stable_since_ms != 0U &&
          (uint32_t)(now_ms - alt_auto_vz_stable_since_ms) >=
              ALT_AUTO_VZ_STABLE_MS) {
        alt_hold_auto_latched = 1U;
        alt_auto_stable_capture_done = 1U;
        alt_auto_stable_anchor_us = throttle_now;
        alt_auto_release_since_ms = 0U;
        alt_auto_vz_stable_since_ms = 0U;
      } else if (airborne && !alt_auto_stable_capture_done &&
                 (uint32_t)(now_ms - alt_auto_last_move_ms) >=
                     ALT_AUTO_STABLE_MS) {
        /* CH3 is steady, but the aircraft is still climbing/falling too fast.
         * cap=1 makes this intentionally delayed capture visible in the log. */
        alt_hold_capture_settle_debug = 1U;
      }
      alt_hold_request_cmd = (alt_hold_switch_request_cmd || alt_hold_auto_latched)
                           ? 1U : 0U;
    }
    /* Horizontal hold is automatic: the right stick has priority while it is
     * moved, then its new position is captured when the stick returns centre. */
    flow_hold_request_cmd = (remote.armed && !auto_land_complete) ? 1U : 0U;
    FlowHold_Update(remote.roll_target_deg, remote.pitch_target_deg,
                    auto_land_active ? auto_land_output_pwm : throttle_slewed_cmd);

    if (debug_mode) {
      static uint32_t debug_imu_tick = 0U;
      uint32_t debug_imu_now = HAL_GetTick();
      if ((uint32_t)(debug_imu_now - debug_imu_tick) >= 5U &&
          BMI088_ReadAll(&hi2c1, &imu) == HAL_OK) {
        debug_imu_tick = debug_imu_now;
        imu.gx -= gx_off;
        imu.gy -= gy_off;
        imu.gz -= gz_off;

        /* 与官方sensor_raw_update一致，在姿态融合和PID之前过滤IMU。 */
        imu.ax = butterworth(imu.ax, &accel_lpf_buf[0], &accel_lpf_param);
        imu.ay = butterworth(imu.ay, &accel_lpf_buf[1], &accel_lpf_param);
        imu.az = butterworth(imu.az, &accel_lpf_buf[2], &accel_lpf_param);
        imu.gx = butterworth(imu.gx, &gyro_lpf_buf[0], &gyro_lpf_param);
        imu.gy = butterworth(imu.gy, &gyro_lpf_buf[1], &gyro_lpf_param);
        imu.gz = butterworth(imu.gz, &gyro_lpf_buf[2], &gyro_lpf_param);
        if (FastAbs(imu.gz) < GYRO_Z_DEADBAND_DPS) imu.gz = 0.0f;
        float pitch_acc = atan2f(imu.ay, sqrtf(imu.ax*imu.ax + imu.az*imu.az)) * 57.2958f;
        float roll_acc  = atan2f(imu.ax, sqrtf(imu.ay*imu.ay + imu.az*imu.az)) * 57.2958f;
        pitch = ATTITUDE_ALPHA * (pitch + imu.gx * CONTROL_DT)
              + (1.0f - ATTITUDE_ALPHA) * pitch_acc;
        roll  = ATTITUDE_ALPHA * (roll - imu.gy * CONTROL_DT)
              + (1.0f - ATTITUDE_ALPHA) * roll_acc;
        /* 官方级联PID: 外环(角度P) → 内环(角速度PID+巴特沃斯D项) */
        float pdr = Attitude_Update_Outer(&pid_pitch, pitch_target_cmd, pitch, 0.01f);
        float rdr = Attitude_Update_Outer(&pid_roll,  roll_target_cmd,  roll,  0.01f);
        float po = PID_Update_Inner(&pid_pitch_rate, pdr, imu.gx,  0.01f);
        float ro = PID_Update_Inner(&pid_roll_rate,  rdr, -imu.gy, 0.01f);
        /* 调试模式绝不向ESC输出起转脉宽，只计算并显示控制量。 */
        mixer.pitch_out = po;
        mixer.roll_out  = ro;
        mixer.yaw_out   = 0;
        mixer.m1 = 990.0f;
        mixer.m2 = 990.0f;
        mixer.m3 = 990.0f;
        mixer.m4 = 990.0f;
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 990);
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 990);
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 990);
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 990);
      }
    }

    /* Safe optical-flow/gyro direction test at 10 Hz.  It deliberately prints
     * both gyro-compensation signs so a hand translation/tilt sequence can
     * determine the sensor mounting matrix without ever starting the motors. */
    if (ENABLE_ASCII_DEBUG && debug_mode) {
      static uint32_t tof_dbg_tick = 0U;
      uint32_t tof_dbg_now = HAL_GetTick();
      if ((uint32_t)(tof_dbg_now - tof_dbg_tick) >= 100U &&
          HAL_UART_GetState(&huart1) == HAL_UART_STATE_READY) {
        float test_dt = (float)opt_origin_data.integration_timespan * 0.000001f;
        float test_h = tof_height_valid ? tof_height_mm : 200.0f;
        float test_raw_vx = 0.0f;
        float test_raw_vy = 0.0f;
        float test_gx_map = imu.gy * DEG_TO_RAD_F;
        float test_gy_map = imu.gx * DEG_TO_RAD_F;
        if (test_dt >= 0.001f) {
          test_raw_vx = -(float)opt_origin_data.pixel_flow_x_integral
                      * test_h / (10000.0f * test_dt);
          test_raw_vy = -(float)opt_origin_data.pixel_flow_y_integral
                      * test_h / (10000.0f * test_dt);
        }
        printf("DIR pix=%d,%d dt=%uus q=%u upd=%u | h=%.0f "
               "att=%.1f,%.1f gyro=%.1f,%.1f,%.1f | rawV=%.0f,%.0f "
               "gMap=%.2f,%.2f plus=%.0f,%.0f minus=%.0f,%.0f "
               "fr=%lu err=%lu/%08lX motor=990\r\n",
               (int)opt_origin_data.pixel_flow_x_integral,
               (int)opt_origin_data.pixel_flow_y_integral,
               (unsigned int)opt_origin_data.integration_timespan,
               (unsigned int)opt_data.qual,
               (unsigned int)opt_data.update,
               test_h, pitch, roll, imu.gx, imu.gy, imu.gz,
               test_raw_vx, test_raw_vy,
               test_gx_map, test_gy_map,
               test_raw_vx + test_gx_map * test_h,
               test_raw_vy + test_gy_map * test_h,
               test_raw_vx - test_gx_map * test_h,
               test_raw_vy - test_gy_map * test_h,
               (unsigned long)flow_parse_count,
               (unsigned long)uart_err_cnt,
               (unsigned long)uart_last_err);
        opt_data.update = 0U;
        tof_dbg_tick = tof_dbg_now;
      }
    }

    if (ENABLE_NCLINK) {
      /* The current attitude convention is pitch rate = +gx and roll rate =
       * -gy.  PID writes are deliberately accepted only while disarmed. */
      NCLink_Service(HAL_GetTick(),
                     &pid_roll_rate, &pid_pitch_rate, &pid_yaw_rate,
                     &pid_roll, &pid_pitch,
                     roll, pitch, yaw,
                     -imu.gy, imu.gx, imu.gz,
                     remote.armed,
                     remote.armed ? 0U : 1U);
    }

    static uint32_t dbg_tick = 0;
    static char dbg_tx[1000];
    if (ENABLE_ASCII_DEBUG && !debug_mode && (HAL_GetTick() - dbg_tick > 500U) &&
        HAL_UART_GetState(&huart1) == HAL_UART_STATE_READY) {
      int dbg_len = snprintf(dbg_tx, sizeof(dbg_tx),
        "A p=%.2f r=%.2f y=%.1f g=%.1f,%.1f,%.1f yh=%.1f | O=%.1f,%.1f I=%.1f,%.1f | "
        "M b=%u %u,%u,%u,%u sat=%u ig=%.2f | RC ch=%u,%u,%u,%u "
        "aux=%u,%u,%u,%u tgt=%.1f,%.1f con=%u fs=%u rec=%u age=%lums fr=%lu bad=%lu gl=%lu | "
        "ALT on=%u req=%u auto=%u fault=%u cap=%u h=%.0f tgt=%.0f hov=%.0f out=%.0f vz=%.0f ctr=%.0f age=%lu tofE=%lu/%lu busy=%u | "
        "LAND on=%u st=%u why=%u ovr=%u rel=%.0f tgt=%.0f out=%.0f vz=%.0f | "
        "FLOW on=%u eff=%u seed=%u req=%u fault=%u q=%u blend=%.2f posE=%.0f,%.0f velB=%.0f,%.0f rawB=%.0f,%.0f velE=%.0f,%.0f cmdE=%.0f,%.0f cmdB=%.0f,%.0f fg=%.2f,%.2f corr=%.2f,%.2f lim=%.1f fi=%.2f,%.2f age=%lu fr=%lu | "
        "START work=%u idle=%u guard=%u trim=%.2f gh=%.0f | PWM c=%lu,%lu,%lu,%lu run=%u,%u,%u | "
        "IMU fail=%lu bus=%lu stale=%u ov=%lu\r\n",
        pitch, roll, yaw, imu.gx, imu.gy, imu.gz, yaw_hold_rate_debug,
        mixer.pitch_out, mixer.roll_out,
        pid_pitch_rate.integrate, pid_roll_rate.integrate,
        throttle_base_debug,
        (uint16_t)mixer.m1, (uint16_t)mixer.m2,
        (uint16_t)mixer.m3, (uint16_t)mixer.m4, mixer_saturated,
        attitude_integral_scale,
        remote.channel[0], remote.channel[1],
        remote.channel[2], remote.channel[3],
        remote.channel[4], remote.channel[5],
        remote.channel[6], remote.channel[7],
        remote.roll_target_deg, remote.pitch_target_deg,
        remote.connected, remote.failsafe, remote.failsafe_recovery_count,
        (unsigned long)(HAL_GetTick() - remote.last_frame_ms),
        (unsigned long)remote.frame_count,
        (unsigned long)remote.bad_frame_count,
        (unsigned long)remote.pulse_error_count,
        alt_hold_enabled, alt_hold_request_cmd, alt_hold_auto_latched, alt_hold_fault,
        alt_hold_capture_settle_debug,
        tof_height_mm, height_target_mm, alt_hold_hover_pwm,
        alt_hold_output_pwm, alt_hold_vz_mm_s, alt_hold_stick_center_pwm,
        (unsigned long)(HAL_GetTick() - tof_last_valid_ms),
        (unsigned long)ms53l0_runtime_i2c_errors,
        (unsigned long)ms53l0_runtime_timeouts,
        (unsigned int)MS53L0_MeasurementActive(),
        auto_land_active, auto_land_state, auto_land_reason,
        ceiling_land_pilot_override,
        auto_land_relative_mm, auto_land_target_mm, auto_land_output_pwm,
        auto_land_vz_mm_s,
        flow_hold_active, flow_hold_effective, flow_velocity_seeded_debug,
        flow_hold_request_cmd, flow_hold_fault,
        opt_origin_data.qual, flow_hold_blend,
        flow_body_x_mm, flow_body_y_mm,
        flow_body_vx_mm_s, flow_body_vy_mm_s,
        flow_raw_vx_mm_s, flow_raw_vy_mm_s,
        flow_earth_vx_mm_s, flow_earth_vy_mm_s,
        flow_desired_earth_vx_mm_s, flow_desired_earth_vy_mm_s,
        flow_desired_body_vx_mm_s, flow_desired_body_vy_mm_s,
        flow_gyro_x_rad_s, flow_gyro_y_rad_s,
        flow_roll_correction_deg, flow_pitch_correction_deg,
        flow_angle_limit_debug,
        pid_flow_x.integrate, pid_flow_y.integrate,
        (unsigned long)(HAL_GetTick() - flow_last_sample_ms),
        (unsigned long)flow_parse_count,
        (mixer.throttle >= RC_CONTROL_WORK_PWM) ? 1U : 0U,
        motor_idle_ramp_active,
        takeoff_guard_active_debug,
        motor_trim_blend_debug,
        flow_ground_height_mm,
        TIM1->CCR1, TIM1->CCR4, TIM2->CCR1, TIM2->CCR2,
        (TIM1->CR1 & TIM_CR1_CEN) ? 1U : 0U,
        (TIM1->BDTR & TIM_BDTR_MOE) ? 1U : 0U,
        (TIM2->CR1 & TIM_CR1_CEN) ? 1U : 0U,
        imu_fail, imu_bus_read_fail, imu_consecutive_fail, control_overrun);
      if (dbg_len > 0) {
        uint16_t send_len = (dbg_len < (int)sizeof(dbg_tx))
                          ? (uint16_t)dbg_len : (uint16_t)(sizeof(dbg_tx) - 1U);
        (void)HAL_UART_Transmit_IT(&huart1, (uint8_t *)dbg_tx, send_len);
      }
      dbg_tick = HAL_GetTick();
    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USART1 使用寄存器方式读 SR/DR。返回 1 让向量入口跳过
 * HAL_UART_IRQHandler()，避免 HAL 再次处理已经读走的字节。
 * 函数放在 USER CODE 区，CubeMX 重新生成时不会覆盖。 */
uint8_t App_USART1_IRQHandler(void)
{
    uint32_t status = USART1->SR;

    if ((status & (USART_SR_RXNE | USART_SR_ORE | USART_SR_NE |
                   USART_SR_FE | USART_SR_PE)) != 0U) {
        uint8_t data = (uint8_t)USART1->DR; /* Reading SR then DR clears RX/error flags. */
        if (((status & USART_SR_RXNE) != 0U) &&
            ((status & (USART_SR_NE | USART_SR_FE | USART_SR_PE)) == 0U)) {
            NCLink_RxByteIRQ(data);
        }
        return 1U;
    }

    return 0U;
}

/* Height control runs inside TIM3 but updates only when a new 20 Hz TOF
 * sample arrives. CH5 provides an explicit, bumpless manual/hold switch. */
static void AltHold_Update(float manual_throttle, uint8_t idle_ramp_active)
{
    static uint32_t last_seq = 0U;
    static uint32_t last_sample_ms = 0U;
    static float last_height_mm = 0.0f;
    static float correction_pwm = 0.0f;
    static float pre_capture_pwm = 0.0f;
    static uint8_t pre_capture_active = 0U;
    uint32_t now = HAL_GetTick();
    uint8_t height_fresh = (tof_last_valid_ms != 0U) &&
                           ((uint32_t)(now - tof_last_valid_ms) <= ALT_HOLD_STALE_MS);
    uint8_t airborne_ready = height_fresh &&
        ((flow_ground_height_valid &&
          tof_height_mm >= flow_ground_height_mm + ALT_HOLD_AIRBORNE_RISE_MM) ||
         (!flow_ground_height_valid && tof_height_mm >= ALT_HOLD_MIN_MM));
    if (!alt_hold_enabled) {
        float capture_throttle = manual_throttle;
        correction_pwm = 0.0f;
        alt_hold_vz_mm_s = 0.0f;

        /* Once CH3 is steady, do not merely wait while a high throttle keeps
         * accelerating the aircraft through the safety ceiling.  Apply a
         * small velocity-only pre-brake, then hold that PWM while |vz| settles.
         * Position control still starts only after the main-loop qualification. */
        if (!alt_hold_request_cmd && alt_hold_capture_settle_debug &&
            !idle_ramp_active && airborne_ready) {
            float requested = pre_capture_pwm;
            if (!pre_capture_active) {
                pre_capture_pwm = manual_throttle;
                pre_capture_active = 1U;
                requested = pre_capture_pwm;
            }
            if (tof_vz_est_mm_s > ALT_AUTO_CAPTURE_MAX_VZ_MM_S) {
                float brake = constrain_float(
                    (tof_vz_est_mm_s - ALT_AUTO_CAPTURE_MAX_VZ_MM_S) *
                        ALT_PRECAPTURE_VZ_GAIN + 3.0f,
                    3.0f, ALT_PRECAPTURE_ASCENT_BRAKE_MAX_US);
                requested = manual_throttle - brake;
            } else if (tof_vz_est_mm_s < -ALT_AUTO_CAPTURE_MAX_VZ_MM_S) {
                float boost = constrain_float(
                    (-tof_vz_est_mm_s - ALT_AUTO_CAPTURE_MAX_VZ_MM_S) *
                        ALT_PRECAPTURE_VZ_GAIN + 2.0f,
                    2.0f, ALT_PRECAPTURE_DESCENT_BOOST_MAX_US);
                requested = manual_throttle + boost;
            }
            if (requested > pre_capture_pwm + ALT_PRECAPTURE_PWM_STEP)
                pre_capture_pwm += ALT_PRECAPTURE_PWM_STEP;
            else if (requested < pre_capture_pwm - ALT_PRECAPTURE_PWM_STEP)
                pre_capture_pwm -= ALT_PRECAPTURE_PWM_STEP;
            else
                pre_capture_pwm = requested;
            pre_capture_pwm = constrain_float(pre_capture_pwm,
                                              ALT_HOLD_ENGAGE_LOW,
                                              ALT_HOLD_ENGAGE_HIGH);
            alt_hold_output_pwm = pre_capture_pwm;
            alt_hold_vz_mm_s = tof_vz_est_mm_s;
            mixer.throttle = pre_capture_pwm;
            return;
        }

        if (alt_hold_request_cmd && pre_capture_active) {
            capture_throttle = pre_capture_pwm;
            mixer.throttle = capture_throttle;
        } else if (!alt_hold_capture_settle_debug) {
            pre_capture_active = 0U;
        }
        alt_hold_output_pwm = capture_throttle;
        if (alt_hold_request_cmd && !idle_ramp_active && airborne_ready &&
            manual_throttle >= ALT_HOLD_ENGAGE_LOW &&
            manual_throttle <= ALT_HOLD_ENGAGE_HIGH &&
            tof_height_mm >= ALT_HOLD_MIN_MM &&
            tof_height_mm <= ALT_HOLD_MAX_MM) {
            float capture_bias_pwm = 0.0f;
            height_target_mm = tof_height_mm;
            if (tof_vz_est_mm_s > 0.0f) {
                capture_bias_pwm = constrain_float(
                    tof_vz_est_mm_s * ALT_HOLD_CAPTURE_VZ_PWM_GAIN,
                    0.0f, ALT_HOLD_CAPTURE_BIAS_MAX_US);
            }
            alt_hold_hover_pwm = constrain_float(capture_throttle - capture_bias_pwm,
                                                  MOTOR_MIN,
                                                  ALT_HOLD_HOVER_PWM_MAX);
            alt_hold_output_pwm = capture_throttle;
            mixer.throttle = capture_throttle;
            alt_hold_stick_center_pwm = throttle_target_cmd;
            last_height_mm = tof_height_mm;
            last_sample_ms = tof_last_valid_ms;
            last_seq = tof_update_seq;
            alt_hold_vz_mm_s = tof_vz_est_mm_s;
            PID_Reset(&pid_height);
            alt_hold_fault = 0U;
            alt_hold_capture_settle_debug = 0U;
            alt_hold_enabled = 1U;
            pre_capture_active = 0U;
        }
        return;
    }

    pre_capture_active = 0U;

    if (!alt_hold_request_cmd || idle_ramp_active || !height_fresh) {
        if (!height_fresh) alt_hold_fault = 1U;
        /* Leave hold from its current output, then let the existing manual
         * throttle slew move toward CH3 without a common-motor PWM step. */
        throttle_slewed_cmd = alt_hold_output_pwm;
        mixer.throttle = alt_hold_output_pwm;
        alt_hold_enabled = 0U;
        alt_hold_capture_settle_debug = 0U;
        PID_Reset(&pid_height);
        alt_hold_recenter_cmd = 0U;
        return;
    }

    /* CH5 deliberately freezes height.  Automatic hold uses the captured CH3
     * position as a neutral point: a moderate displacement moves the height
     * target, while the main loop still releases hold on a large displacement. */

    if (tof_update_seq != last_seq) {
        float dt = (last_sample_ms == 0U) ? 0.05f :
                   (float)(tof_last_valid_ms - last_sample_ms) * 0.001f;
        dt = constrain_float(dt, 0.02f, 0.20f);
        if (alt_hold_auto_latched && !alt_hold_switch_request_cmd) {
            float stick_delta = throttle_target_cmd - alt_hold_stick_center_pwm;
            float stick_magnitude = FastAbs(stick_delta);
            if (stick_magnitude > ALT_HOLD_STICK_DEADBAND) {
                float command_span = (float)ALT_AUTO_RELEASE_CHANGE_US -
                                     ALT_HOLD_STICK_DEADBAND;
                float climb_rate = (stick_magnitude - ALT_HOLD_STICK_DEADBAND) /
                                   command_span * ALT_HOLD_MAX_CLIMB_MM_S;
                climb_rate = constrain_float(climb_rate, 0.0f,
                                             ALT_HOLD_MAX_CLIMB_MM_S);
                if (stick_delta < 0.0f) climb_rate = -climb_rate;
                height_target_mm = constrain_float(height_target_mm + climb_rate * dt,
                                                   ALT_HOLD_MIN_MM,
                                                   ALT_HOLD_MAX_MM);
            }
        }
        {
            float vz = (tof_height_mm - last_height_mm) / dt;
            vz = constrain_float(vz, -ALT_HOLD_VZ_RAW_LIMIT,
                                 ALT_HOLD_VZ_RAW_LIMIT);
            alt_hold_vz_mm_s =
                (1.0f - ALT_HOLD_VZ_LPF_ALPHA) * alt_hold_vz_mm_s +
                ALT_HOLD_VZ_LPF_ALPHA * vz;
        }
        correction_pwm = PID_Update_Outer(&pid_height, height_target_mm,
                                          tof_height_mm, dt)
                       - ALT_HOLD_VZ_KD * alt_hold_vz_mm_s;
        correction_pwm = constrain_float(correction_pwm,
                                         -ALT_HOLD_CORR_LIMIT,
                                         ALT_HOLD_CORR_LIMIT);
        /* Log90 showed that a transient +60 us catch arrived after the fall
         * had already ended and pumped the frame to 890 mm.  Learn the small
         * persistent hover bias instead, and only while vertical motion is
         * slow enough that the sample represents load/battery rather than an
         * oscillation. */
        if (FastAbs(height_target_mm - tof_height_mm) <=
                ALT_HOLD_HOVER_LEARN_ERR_MM &&
            FastAbs(alt_hold_vz_mm_s) <=
                ALT_HOLD_HOVER_LEARN_VZ_MM_S) {
            float learn_step = constrain_float(
                (height_target_mm - tof_height_mm) *
                    ALT_HOLD_HOVER_LEARN_ERR_GAIN -
                alt_hold_vz_mm_s * ALT_HOLD_HOVER_LEARN_VZ_GAIN,
                -ALT_HOLD_HOVER_LEARN_STEP, ALT_HOLD_HOVER_LEARN_STEP);
            alt_hold_hover_pwm = constrain_float(
                alt_hold_hover_pwm + learn_step,
                ALT_HOLD_ENGAGE_LOW, ALT_HOLD_HOVER_PWM_MAX);
        }
        last_height_mm = tof_height_mm;
        last_sample_ms = tof_last_valid_ms;
        last_seq = tof_update_seq;
    }

    {
        float allowed_drop = ALT_HOLD_OUTPUT_DROP_US;
        float hold_floor;
        float hold_ceiling = alt_hold_hover_pwm + ALT_HOLD_OUTPUT_RISE_US;
        float rise_step = ALT_HOLD_PWM_SLEW_UP_STEP;
        float fall_step = ALT_HOLD_PWM_SLEW_DOWN_STEP;
        float requested;
        /* The former hover-20us floor could not arrest a real climb.  Permit
         * more reduction only while vertical speed or height error confirms
         * an ascent; the asymmetric slew still prevents a throttle step. */
        if (alt_hold_vz_mm_s > ALT_HOLD_ASCENT_BRAKE_VZ ||
            tof_height_mm > height_target_mm + ALT_HOLD_ASCENT_BRAKE_ERR) {
            allowed_drop = ALT_HOLD_ASCENT_DROP_US;
            fall_step = ALT_HOLD_ASCENT_SLEW_DOWN_STEP;
        }
        hold_floor = alt_hold_hover_pwm - allowed_drop;
        if (hold_floor < MOTOR_MIN) hold_floor = MOTOR_MIN;
        if (hold_ceiling > MOTOR_MAX) hold_ceiling = MOTOR_MAX;
        requested = constrain_float(alt_hold_hover_pwm + correction_pwm,
                                    hold_floor, hold_ceiling);
        /* A confirmed descent may restore thrust earlier and slightly faster;
         * the configured hold ceiling still bounds the recovery authority. */
        if (alt_hold_vz_mm_s <= ALT_HOLD_FAST_DESCENT_VZ)
            rise_step = ALT_HOLD_FAST_CATCH_STEP;
        if (requested > alt_hold_output_pwm + rise_step)
            alt_hold_output_pwm += rise_step;
        else if (requested < alt_hold_output_pwm - fall_step)
            alt_hold_output_pwm -= fall_step;
        else
            alt_hold_output_pwm = requested;
        mixer.throttle = alt_hold_output_pwm;
    }
}

/* Latched emergency landing.  RC loss and the CH6 switch keep the complete
 * attitude controller running; only the common throttle is replaced here.
 * The learned disarmed TOF height is the ground reference.  If TOF becomes
 * stale, fall back to a slow timed throttle reduction and finally stop. */
static void AutoLand_Update(void)
{
    static uint8_t initialized = 0U;
    static uint8_t touchdown_count = 0U;
    static uint8_t ceiling_count = 0U;
    static uint32_t ceiling_last_seq = 0U;
    static uint32_t last_height_seq = 0U;
    static uint32_t last_height_ms = 0U;
    static uint32_t start_ms = 0U;
    static float last_height_mm = 0.0f;
    static float landing_hover_pwm = 0.0f;
    static float landing_vz_mm_s = 0.0f;
    static float correction_pwm = 0.0f;
    uint32_t now = HAL_GetTick();
    uint8_t height_fresh = tof_last_valid_ms != 0U &&
                           (uint32_t)(now - tof_last_valid_ms) <= AUTOLAND_SENSOR_STALE_MS;

    /* A ceiling-triggered landing is only a soft protection.  Log57 showed
     * that keeping it latched after the pilot pulled CH3 fully low made a
     * healthy receiver look uncontrollable.  Low CH3 therefore cancels only
     * reason 3 and inhibits another ceiling trigger until the next arming.
     * CH6 emergency landing and RC-loss landing remain latched. */
    if (auto_land_active && auto_land_reason == 3U &&
        throttle_target_cmd <= SAFETY_CEILING_OVERRIDE_PWM) {
        ceiling_land_pilot_override = 1U;
        auto_land_active = 0U;
        auto_land_reason = 0U;
        auto_land_state = 0U;
        initialized = 0U;
        ceiling_count = 0U;
        throttle_slewed_cmd = constrain_float(throttle_target_cmd,
                                               RAMP_START,
                                               RC_FLIGHT_TEST_MAX_PWM);
        mixer.throttle = throttle_slewed_cmd;
        alt_hold_output_pwm = mixer.throttle;
        PID_Reset(&pid_height);
        return;
    }

    if (!auto_land_active) {
        initialized = 0U;
        touchdown_count = 0U;
        auto_land_state = 0U;
        auto_land_relative_mm = 0.0f;
        auto_land_vz_mm_s = 0.0f;

        /* A three-sample confirmation prevents one reflective-floor spike
         * from converting an ordinary manual flight into an emergency land. */
        if (!ceiling_land_pilot_override && height_fresh && flow_ground_height_valid &&
            tof_update_seq != ceiling_last_seq) {
            ceiling_last_seq = tof_update_seq;
            if (tof_height_mm - flow_ground_height_mm >= SAFETY_CEILING_RISE_MM) {
                if (ceiling_count < 0xFFU) ceiling_count++;
            } else {
                ceiling_count = 0U;
            }
            if (ceiling_count >= SAFETY_CEILING_CONFIRM_SAMPLES) {
                auto_land_active = 1U;
                auto_land_reason = 3U;
            }
        }
        if (!auto_land_active) return;
    }

    if (auto_land_complete) {
        auto_land_state = 3U;
        auto_land_output_pwm = IMU_FS_STOP_PWM;
        mixer.throttle = IMU_FS_STOP_PWM;
        return;
    }

    if (!initialized) {
        float ground_mm = flow_ground_height_valid ? flow_ground_height_mm
                                                    : ALT_HOLD_MIN_MM;
        initialized = 1U;
        touchdown_count = 0U;
        start_ms = now;
        last_height_seq = tof_update_seq;
        last_height_ms = tof_last_valid_ms;
        last_height_mm = tof_height_mm;
        landing_vz_mm_s = 0.0f;
        correction_pwm = 0.0f;
        /* A ceiling event often starts after height hold has already reduced
         * throttle.  Reuse its learned hover value instead of treating that
         * temporary braking output as the aircraft's hover throttle. */
        landing_hover_pwm = mixer.throttle;
        if (alt_hold_hover_pwm >= ALT_HOLD_ENGAGE_LOW &&
            alt_hold_hover_pwm > landing_hover_pwm)
            landing_hover_pwm = alt_hold_hover_pwm;
        landing_hover_pwm = constrain_float(landing_hover_pwm, MOTOR_MIN,
                                            AUTOLAND_HOVER_PWM_MAX);
        /* Do not step the motors at mode entry. */
        auto_land_output_pwm = constrain_float(mixer.throttle, MOTOR_MIN,
                                               RC_FLIGHT_TEST_MAX_PWM);
        auto_land_target_mm = height_fresh ? tof_height_mm : ground_mm + SAFETY_CEILING_RISE_MM;
        auto_land_relative_mm = height_fresh ? tof_height_mm - ground_mm : 0.0f;
        auto_land_state = 1U;
        PID_Reset(&pid_height);
    }

    if ((uint32_t)(now - start_ms) >= AUTOLAND_MAX_TIME_MS) {
        auto_land_state = 2U;
    }

    if (auto_land_state == 1U && height_fresh &&
        tof_update_seq != last_height_seq) {
        float ground_mm = flow_ground_height_valid ? flow_ground_height_mm
                                                    : ALT_HOLD_MIN_MM;
        float dt = (last_height_ms == 0U) ? 0.05f :
                   (float)(tof_last_valid_ms - last_height_ms) * 0.001f;
        float descent_rate;
        float landing_floor;
        float landing_ceiling;
        float requested;
        dt = constrain_float(dt, 0.02f, 0.20f);
        auto_land_relative_mm = tof_height_mm - ground_mm;
        descent_rate = (auto_land_relative_mm <= AUTOLAND_FLARE_HEIGHT_MM)
                     ? AUTOLAND_FLARE_MM_S : AUTOLAND_DESCENT_MM_S;
        auto_land_target_mm -= descent_rate * dt;
        if (auto_land_target_mm < ground_mm + 10.0f)
            auto_land_target_mm = ground_mm + 10.0f;

        {
            float raw_vz = (tof_height_mm - last_height_mm) / dt;
            raw_vz = constrain_float(raw_vz, -ALT_HOLD_VZ_RAW_LIMIT,
                                     ALT_HOLD_VZ_RAW_LIMIT);
            landing_vz_mm_s = 0.85f * landing_vz_mm_s + 0.15f * raw_vz;
        }
        auto_land_vz_mm_s = landing_vz_mm_s;
        correction_pwm = PID_Update_Outer(&pid_height, auto_land_target_mm,
                                          tof_height_mm, dt)
                       - ALT_HOLD_VZ_KD * landing_vz_mm_s;
        correction_pwm = constrain_float(correction_pwm,
                                         -AUTOLAND_CORR_LIMIT,
                                         AUTOLAND_CORR_LIMIT);
        landing_floor = landing_hover_pwm - AUTOLAND_OUTPUT_DROP_US;
        landing_ceiling = landing_hover_pwm + AUTOLAND_OUTPUT_RISE_US;
        if (landing_floor < MOTOR_MIN) landing_floor = MOTOR_MIN;
        if (landing_ceiling > MOTOR_MAX) landing_ceiling = MOTOR_MAX;
        requested = constrain_float(landing_hover_pwm + correction_pwm,
                                    landing_floor, landing_ceiling);
        /* This slew used to be a fixed 0.75 us per TOF frame.  At roughly
         * 20 Hz that was only 15 us/s, so CH6 still left the aircraft at its
         * climbing throttle for several seconds.  Scale by real elapsed time
         * and remove throttle faster whenever it is still ascending. */
        {
            float fall_rate = AUTOLAND_PWM_FALL_US_S;
            float rise_step = AUTOLAND_PWM_RISE_US_S * dt;
            float fall_step;
            if (landing_vz_mm_s >= AUTOLAND_ASCENT_MM_S ||
                auto_land_output_pwm > landing_hover_pwm ||
                auto_land_relative_mm >= SAFETY_CEILING_RISE_MM) {
                fall_rate = AUTOLAND_ASCENT_FALL_US_S;
            }
            fall_step = fall_rate * dt;
            if (requested > auto_land_output_pwm + rise_step)
                auto_land_output_pwm += rise_step;
            else if (requested < auto_land_output_pwm - fall_step)
                auto_land_output_pwm -= fall_step;
            else
                auto_land_output_pwm = requested;
        }

        if (auto_land_relative_mm <= AUTOLAND_TOUCHDOWN_MM) {
            if (touchdown_count < 0xFFU) touchdown_count++;
        } else if (auto_land_relative_mm > AUTOLAND_TOUCHDOWN_MM + 25.0f) {
            touchdown_count = 0U;
        }
        if (touchdown_count >= AUTOLAND_TOUCHDOWN_SAMPLES)
            auto_land_state = 2U;

        last_height_mm = tof_height_mm;
        last_height_ms = tof_last_valid_ms;
        last_height_seq = tof_update_seq;
    } else if (auto_land_state == 1U && !height_fresh) {
        /* No trustworthy range: retain levelling and descend conservatively. */
        if (auto_land_output_pwm > MOTOR_MIN + AUTOLAND_FALLBACK_STEP)
            auto_land_output_pwm -= AUTOLAND_FALLBACK_STEP;
    }

    if (auto_land_state == 2U) {
        if (auto_land_output_pwm > MOTOR_MIN + AUTOLAND_TOUCHDOWN_RAMP_STEP) {
            auto_land_output_pwm -= AUTOLAND_TOUCHDOWN_RAMP_STEP;
        } else {
            auto_land_output_pwm = IMU_FS_STOP_PWM;
            auto_land_complete = 1U;
            auto_land_state = 3U;
        }
    }

    mixer.throttle = auto_land_output_pwm;
}

/* Body axes established by the four direction tests:
 * body X = -flow raw X, body Y = -flow raw Y.
 * Position hold is deliberately body-frame and low-authority for the first
 * flight tests. Moving the right stick releases it; centring relocks there. */
static void FlowHold_Update(float roll_command_deg, float pitch_command_deg,
                            float throttle_us)
{
    static uint32_t last_seq = 0U;
    static uint32_t engage_start_ms = 0U;
    static uint32_t stable_start_ms = 0U;
    static float roll_corr = 0.0f;
    static float pitch_corr = 0.0f;
    static float last_good_vx = 0.0f;
    static float last_good_vy = 0.0f;
    static float manual_vx = 0.0f;
    static float manual_vy = 0.0f;
    static float angle_limit_state = FLOW_TAKEOFF_ANGLE_LIMIT;
    static uint8_t last_good_valid = 0U;
    static uint8_t manual_velocity_valid = 0U;
    static uint8_t reject_count = 0U;
    static uint32_t last_suspend_step_ms = 0U;
    static uint32_t manual_velocity_ms = 0U;
    static uint32_t manual_track_seq = 0U;
    uint32_t now = HAL_GetTick();
    uint8_t flow_fresh = flow_last_sample_ms != 0U &&
                          (uint32_t)(now - flow_last_sample_ms) <= FLOW_STALE_MS;
    /* flow_last_sample_ms is updated only by an accepted >= minimum-quality
     * frame.  The parser still overwrites opt_origin_data when a later frame
     * is poor, so testing its live quality here made hold drop immediately
     * even though the last accepted sample was still fresh.  Use freshness as
     * the quality grace window; no rejected sample is integrated because its
     * sequence number is not advanced. */
    uint8_t flow_quality_good = flow_fresh;
    uint8_t height_fresh = tof_last_valid_ms != 0U &&
                            (uint32_t)(now - tof_last_valid_ms) <= ALT_HOLD_STALE_MS;
    uint8_t throttle_ready = throttle_us >= FLOW_ENGAGE_MIN_PWM;
    uint8_t stick_centered = FastAbs(roll_command_deg) <= FLOW_STICK_DEADBAND &&
                             FastAbs(pitch_command_deg) <= FLOW_STICK_DEADBAND;
    /* Rotation is already removed from optical flow using the filtered gyro.
     * Requiring gyro <20 dps prevented point hold from ever starting during
     * the normal support-frame release impulse.  Keep only a safe angle gate. */
    uint8_t attitude_stable =
        FastAbs(pitch - level_pitch_ref_deg) <= FLOW_LEVEL_MAX_DEG &&
        FastAbs(roll - level_roll_ref_deg) <= FLOW_LEVEL_MAX_DEG;
    float vertical_vz_mm_s = alt_hold_enabled ? alt_hold_vz_mm_s
                                               : tof_vz_est_mm_s;
    uint8_t full_hold_ready = alt_hold_enabled &&
        FastAbs(alt_hold_vz_mm_s) <= FLOW_FULL_MAX_VZ_MM_S &&
        FastAbs(tof_height_mm - height_target_mm) <= FLOW_FULL_MAX_ERR_MM;
    uint8_t vertical_safe = vertical_vz_mm_s > FLOW_SUSPEND_DESCENT_MM_S;
    uint8_t airborne_ready = 0U;
    if (height_fresh) {
        if (flow_ground_height_valid) {
            float required_rise = flow_hold_active ? FLOW_RELEASE_MIN_MM
                                                   : FLOW_TAKEOFF_RISE_MM;
            airborne_ready = tof_height_mm >= flow_ground_height_mm + required_rise;
        } else {
            airborne_ready = tof_height_mm >= FLOW_ENGAGE_MIN_MM;
        }
    }
    uint8_t stable_ready = flow_hold_active;

    /* While the pilot owns roll/pitch, do not output position corrections but
     * keep estimating body velocity.  The old code zeroed velocity here, so a
     * recenter captured a moving aircraft as if it were stationary and only
     * began braking after it had drifted far from the new point. */
    if (!stick_centered && flow_hold_request_cmd && throttle_ready &&
        flow_fresh && flow_quality_good && airborne_ready && attitude_stable &&
        flow_sample_seq != manual_track_seq) {
        float track_dt = constrain_float(
            (float)opt_origin_data.integration_timespan * 0.000001f,
            0.010f, 0.050f);
        float track_height = tof_height_mm;
        float track_raw_x;
        float track_raw_y;
        float track_vx;
        float track_vy;
        if (flow_ground_height_valid && track_height < flow_ground_height_mm)
            track_height = flow_ground_height_mm;
        track_height = constrain_float(track_height, 50.0f, ALT_HOLD_MAX_MM);
        track_raw_x = -(float)opt_origin_data.pixel_flow_x_integral /
                      (10000.0f * track_dt);
        track_raw_y = -(float)opt_origin_data.pixel_flow_y_integral /
                      (10000.0f * track_dt);
        track_vx = (track_raw_x - constrain_float(flow_gyro_x_rad_s,
                                                   -8.0f, 8.0f)) * track_height;
        track_vy = (track_raw_y - constrain_float(flow_gyro_y_rad_s,
                                                   -8.0f, 8.0f)) * track_height;
        manual_track_seq = flow_sample_seq;
        if (FastAbs(track_vx) <= FLOW_SPEED_REJECT_MM_S &&
            FastAbs(track_vy) <= FLOW_SPEED_REJECT_MM_S) {
            if (manual_velocity_valid &&
                (uint32_t)(now - manual_velocity_ms) <=
                    FLOW_MANUAL_VEL_MAX_AGE_MS) {
                manual_vx = 0.55f * manual_vx + 0.45f * track_vx;
                manual_vy = 0.55f * manual_vy + 0.45f * track_vy;
            } else {
                manual_vx = track_vx;
                manual_vy = track_vy;
            }
            manual_velocity_ms = now;
            manual_velocity_valid = 1U;
        }
    }

    if (!flow_hold_active && flow_hold_request_cmd &&
        throttle_ready && flow_fresh && flow_quality_good && airborne_ready &&
        stick_centered && attitude_stable) {
        if (stable_start_ms == 0U)
            stable_start_ms = now;
        if ((uint32_t)(now - stable_start_ms) >= FLOW_STABLE_TIME_MS)
            stable_ready = 1U;
    } else if (!flow_hold_active) {
        stable_start_ms = 0U;
    }

    /* Once locked, a brief bad flow frame, bounce or tilt must not erase the
     * original position and immediately relock at the drifted location.
     * Remove horizontal demand smoothly while height/attitude recovers, but
     * preserve the position/PID state for reacquisition. */
    if (flow_hold_active &&
        (!flow_fresh || !flow_quality_good || !attitude_stable || !vertical_safe)) {
        flow_hold_effective = 0U;
        if (!flow_fresh)
            flow_hold_fault = 1U;
        else if (!flow_quality_good)
            flow_hold_fault = 4U;
        else
            flow_hold_fault = 3U;
        if ((uint32_t)(now - last_suspend_step_ms) >= 20U) {
            last_suspend_step_ms = now;
            if (roll_corr > FLOW_SUSPEND_SLEW_DEG)
                roll_corr -= FLOW_SUSPEND_SLEW_DEG;
            else if (roll_corr < -FLOW_SUSPEND_SLEW_DEG)
                roll_corr += FLOW_SUSPEND_SLEW_DEG;
            else
                roll_corr = 0.0f;
            if (pitch_corr > FLOW_SUSPEND_SLEW_DEG)
                pitch_corr -= FLOW_SUSPEND_SLEW_DEG;
            else if (pitch_corr < -FLOW_SUSPEND_SLEW_DEG)
                pitch_corr += FLOW_SUSPEND_SLEW_DEG;
            else
                pitch_corr = 0.0f;
        }
        flow_roll_correction_deg = roll_corr * flow_hold_blend;
        flow_pitch_correction_deg = pitch_corr * flow_hold_blend;
        angle_limit_state = FLOW_TAKEOFF_ANGLE_LIMIT;
        flow_angle_limit_debug = angle_limit_state;
        last_seq = flow_sample_seq;
        return;
    }

    if (!flow_hold_request_cmd || !throttle_ready ||
        !flow_fresh || !flow_quality_good || !airborne_ready || !stick_centered ||
        (!flow_hold_active && !attitude_stable) ||
        !stable_ready) {
        if (flow_hold_request_cmd && !flow_fresh)
            flow_hold_fault = 1U;
        flow_hold_active = 0U;
        flow_hold_effective = 0U;
        flow_velocity_seeded_debug = 0U;
        if (!flow_hold_request_cmd || !throttle_ready || !airborne_ready) {
            manual_velocity_valid = 0U;
            manual_velocity_ms = 0U;
        }
        flow_body_x_mm = 0.0f;
        flow_body_y_mm = 0.0f;
        flow_body_vx_mm_s = 0.0f;
        flow_body_vy_mm_s = 0.0f;
        flow_raw_vx_mm_s = 0.0f;
        flow_raw_vy_mm_s = 0.0f;
        flow_earth_vx_mm_s = 0.0f;
        flow_earth_vy_mm_s = 0.0f;
        flow_desired_earth_vx_mm_s = 0.0f;
        flow_desired_earth_vy_mm_s = 0.0f;
        flow_desired_body_vx_mm_s = 0.0f;
        flow_desired_body_vy_mm_s = 0.0f;
        roll_corr = 0.0f;
        pitch_corr = 0.0f;
        flow_hold_blend = 0.0f;
        flow_roll_correction_deg = 0.0f;
        flow_pitch_correction_deg = 0.0f;
        flow_angle_limit_debug = 0.0f;
        angle_limit_state = FLOW_TAKEOFF_ANGLE_LIMIT;
        PID_Reset(&pid_flow_x);
        PID_Reset(&pid_flow_y);
        last_good_valid = 0U;
        reject_count = 0U;
        last_suspend_step_ms = now;
        angle_limit_state = FLOW_TAKEOFF_ANGLE_LIMIT;
        last_seq = flow_sample_seq;
        return;
    }

    if (!flow_hold_active) {
        uint8_t seed_velocity = manual_velocity_valid &&
            (uint32_t)(now - manual_velocity_ms) <= FLOW_MANUAL_VEL_MAX_AGE_MS;
        flow_body_x_mm = 0.0f;
        flow_body_y_mm = 0.0f;
        flow_body_vx_mm_s = seed_velocity ? manual_vx : 0.0f;
        flow_body_vy_mm_s = seed_velocity ? manual_vy : 0.0f;
        PID_Reset(&pid_flow_x);
        PID_Reset(&pid_flow_y);
        last_seq = flow_sample_seq;
        flow_hold_fault = 0U;
        engage_start_ms = now;
        stable_start_ms = now;
        flow_hold_blend = 0.0f;
        flow_hold_active = 1U;
        flow_hold_effective = 0U;
        flow_velocity_seeded_debug = seed_velocity;
        last_good_vx = flow_body_vx_mm_s;
        last_good_vy = flow_body_vy_mm_s;
        last_good_valid = seed_velocity;
        reject_count = 0U;
        last_suspend_step_ms = now;
    }

    flow_hold_blend = constrain_float(
        (float)(uint32_t)(now - engage_start_ms) / (float)FLOW_ENGAGE_RAMP_MS,
        0.0f, 1.0f);

    if (flow_sample_seq != last_seq) {
        float dt = (float)opt_origin_data.integration_timespan * 0.000001f;
        /* TOF is used only as optical-flow scale.  A brief invalid or
         * downward-biased reading must not disable horizontal hold. */
        float height_mm = tof_height_mm;
        if (flow_ground_height_valid && height_mm < flow_ground_height_mm)
            height_mm = flow_ground_height_mm;
        height_mm = constrain_float(height_mm, 50.0f, ALT_HOLD_MAX_MM);
        float dx_mm, dy_mm, vx, vy, desired_vx, desired_vy;
        float desired_body_vx, desired_body_vy;
        float yaw_rad, yaw_cos, yaw_sin, earth_vx, earth_vy;
        float raw_ang_x, raw_ang_y, gyro_x, gyro_y;
        float roll_requested, pitch_requested, angle_limit;
        dt = constrain_float(dt, 0.010f, 0.050f);

        /* Translation signs were measured on this airframe:
         * right(+IMU X)/back(+IMU Y) motion produces negative raw flow.
         * Official sensor-frame correction is:
         *   flowX_corrected = flowX - (-gyroY)
         *   flowY_corrected = flowY - (+gyroX)
         * The LC306 is mounted opposite the reference camera X orientation.
         * Flight data showed raw X=65 mm/s becoming a false 190 mm/s when
         * gyroY was subtracted.  The measured installation therefore needs:
         * The hand translation/tilt test showed that the camera rotational
         * flow has the same sign as the mapped BMI088 rate.  It must therefore
         * be subtracted to leave translation-only body velocity:
         *   bodyX = -flowX - gyroY
         *   bodyY = -flowY - gyroX */
        raw_ang_x = -(float)opt_origin_data.pixel_flow_x_integral / (10000.0f * dt);
        raw_ang_y = -(float)opt_origin_data.pixel_flow_y_integral / (10000.0f * dt);
        gyro_x = constrain_float(flow_gyro_x_rad_s, -8.0f, 8.0f);
        gyro_y = constrain_float(flow_gyro_y_rad_s, -8.0f, 8.0f);
        flow_raw_vx_mm_s = raw_ang_x * height_mm;
        flow_raw_vy_mm_s = raw_ang_y * height_mm;
        vx = (raw_ang_x - gyro_x) * height_mm;
        vy = (raw_ang_y - gyro_y) * height_mm;
        /* The takeoff log contained a single 917 mm/s estimate only a few
         * centimetres above the floor.  That frame was accepted as a real
         * drift and demanded the old 4-degree escape correction.  Reject both
         * physically implausible low-hover speeds and abrupt frame-to-frame
         * jumps before they can enter either the position integrator or PID. */
        if (FastAbs(vx) > FLOW_SPEED_REJECT_MM_S ||
            FastAbs(vy) > FLOW_SPEED_REJECT_MM_S ||
            (last_good_valid &&
             (FastAbs(vx - last_good_vx) > FLOW_STEP_REJECT_MM_S ||
              FastAbs(vy - last_good_vy) > FLOW_STEP_REJECT_MM_S))) {
            if (reject_count < 0xFFU) reject_count++;
            flow_hold_fault = 2U;
            last_seq = flow_sample_seq;
            /* Keep the last low-authority correction and the original point
             * through a short reject burst.  Removing it here let the drift
             * accelerate exactly while braking was most necessary. */
            flow_roll_correction_deg = roll_corr * flow_hold_blend;
            flow_pitch_correction_deg = pitch_corr * flow_hold_blend;
            if (reject_count >= FLOW_REJECT_EXIT_COUNT) {
                flow_hold_active = 0U;
                flow_hold_effective = 0U;
                stable_start_ms = 0U;
                flow_hold_blend = 0.0f;
                flow_roll_correction_deg = 0.0f;
                flow_pitch_correction_deg = 0.0f;
                roll_corr = 0.0f;
                pitch_corr = 0.0f;
                last_good_valid = 0U;
                PID_Reset(&pid_flow_x);
                PID_Reset(&pid_flow_y);
            }
            flow_hold_effective = 0U;
            return;
        }
        reject_count = 0U;
        flow_hold_fault = 0U;
        last_good_vx = vx;
        last_good_vy = vy;
        last_good_valid = 1U;
        flow_hold_effective = 1U;
        /* Convert body translation to the takeoff-fixed earth frame before
         * integrating position.  Otherwise a 90-degree yaw turn rotates the
         * meaning of the stored X/Y error and sends recovery the wrong way. */
        yaw_rad = yaw * DEG_TO_RAD_F;
        yaw_cos = cosf(yaw_rad);
        yaw_sin = sinf(yaw_rad);
        earth_vx = yaw_cos * vx - yaw_sin * vy;
        earth_vy = yaw_sin * vx + yaw_cos * vy;
        flow_earth_vx_mm_s = earth_vx;
        flow_earth_vy_mm_s = earth_vy;
        dx_mm = earth_vx * dt;
        dy_mm = earth_vy * dt;
        flow_body_vx_mm_s =
            (1.0f - FLOW_VEL_LPF_ALPHA) * flow_body_vx_mm_s +
            FLOW_VEL_LPF_ALPHA * vx;
        flow_body_vy_mm_s =
            (1.0f - FLOW_VEL_LPF_ALPHA) * flow_body_vy_mm_s +
            FLOW_VEL_LPF_ALPHA * vy;
        flow_body_x_mm += dx_mm;
        flow_body_y_mm += dy_mm;
        flow_body_x_mm = constrain_float(flow_body_x_mm,
                                         -FLOW_POS_LIMIT_MM,
                                         FLOW_POS_LIMIT_MM);
        flow_body_y_mm = constrain_float(flow_body_y_mm,
                                         -FLOW_POS_LIMIT_MM,
                                         FLOW_POS_LIMIT_MM);

        desired_vx = constrain_float(-FLOW_POS_KP * flow_body_x_mm,
                                     -FLOW_VEL_LIMIT, FLOW_VEL_LIMIT);
        desired_vy = constrain_float(-FLOW_POS_KP * flow_body_y_mm,
                                     -FLOW_VEL_LIMIT, FLOW_VEL_LIMIT);
        flow_desired_earth_vx_mm_s = desired_vx;
        flow_desired_earth_vy_mm_s = desired_vy;
        /* Rotate the earth-frame return velocity back into the current body
         * axes, then reuse the verified body roll/pitch signs. */
        desired_body_vx = yaw_cos * desired_vx + yaw_sin * desired_vy;
        desired_body_vy = -yaw_sin * desired_vx + yaw_cos * desired_vy;
        flow_desired_body_vx_mm_s = desired_body_vx;
        flow_desired_body_vy_mm_s = desired_body_vy;
        /* Start braking from measured horizontal speed or a small position
         * error instead of waiting for height hold to settle.  The lower
         * 1.4-degree ceiling and faster slew give an early short correction
         * rather than a late, long correction that crosses the held point. */
        {
            uint8_t quality_brake_ready =
                opt_origin_data.qual >= FLOW_BRAKE_MIN_QUALITY &&
                (FastAbs(flow_body_vx_mm_s) >= FLOW_BRAKE_MIN_SPEED_MM_S ||
                 FastAbs(flow_body_vy_mm_s) >= FLOW_BRAKE_MIN_SPEED_MM_S ||
                 FastAbs(flow_body_x_mm) >= FLOW_BRAKE_MIN_POS_MM ||
                 FastAbs(flow_body_y_mm) >= FLOW_BRAKE_MIN_POS_MM);
            float target_angle_limit = quality_brake_ready
                                     ? FLOW_BRAKE_ANGLE_LIMIT
                                     : (full_hold_ready ? FLOW_ANGLE_LIMIT
                                                        : FLOW_TAKEOFF_ANGLE_LIMIT);
            if (angle_limit_state < target_angle_limit - FLOW_LIMIT_SLEW_DEG)
                angle_limit_state += FLOW_LIMIT_SLEW_DEG;
            else if (angle_limit_state > target_angle_limit + FLOW_LIMIT_SLEW_DEG)
                angle_limit_state -= FLOW_LIMIT_SLEW_DEG;
            else
                angle_limit_state = target_angle_limit;
            angle_limit_state = constrain_float(angle_limit_state,
                                                 FLOW_TAKEOFF_ANGLE_LIMIT,
                                                 FLOW_BRAKE_ANGLE_LIMIT);
            angle_limit = angle_limit_state;
        }
        pid_flow_x.control_output_limit = angle_limit;
        pid_flow_y.control_output_limit = angle_limit;
        flow_angle_limit_debug = angle_limit;
        roll_requested = FLOW_ROLL_SIGN * PID_Update_Outer(
            &pid_flow_x, desired_body_vx, flow_body_vx_mm_s, dt);
        pitch_requested = FLOW_PITCH_SIGN * PID_Update_Outer(
            &pid_flow_y, desired_body_vy, flow_body_vy_mm_s, dt);
        roll_requested = constrain_float(roll_requested,
                                         -angle_limit, angle_limit);
        pitch_requested = constrain_float(pitch_requested,
                                          -angle_limit, angle_limit);
        if (roll_requested > roll_corr + FLOW_CORR_SLEW_DEG)
            roll_corr += FLOW_CORR_SLEW_DEG;
        else if (roll_requested < roll_corr - FLOW_CORR_SLEW_DEG)
            roll_corr -= FLOW_CORR_SLEW_DEG;
        else
            roll_corr = roll_requested;
        if (pitch_requested > pitch_corr + FLOW_CORR_SLEW_DEG)
            pitch_corr += FLOW_CORR_SLEW_DEG;
        else if (pitch_requested < pitch_corr - FLOW_CORR_SLEW_DEG)
            pitch_corr -= FLOW_CORR_SLEW_DEG;
        else
            pitch_corr = pitch_requested;
        flow_roll_correction_deg = roll_corr * flow_hold_blend;
        flow_pitch_correction_deg = pitch_corr * flow_hold_blend;
        last_seq = flow_sample_seq;
    }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == GPIO_PIN_9) {
        YaoKong_PPM_IRQHandler();
    }
}

/* TIM3定时中断回调 - 官方同频200Hz控制循环
 * 控制循环在中断中运行, 不受主循环printf/TOF/光流影响, dt固定5ms
 * NVIC优先级: SysTick=0(最高) > TIM3=1 > USART2=2
 * SysTick优先级设为0确保HAL_I2C的HAL_GetTick超时机制在中断中正常工作 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    uint32_t control_start_cycles;
    uint32_t elapsed_cycles;

    if (htim->Instance != TIM3) return;
    control_start_cycles = DWT->CYCCNT;

    /* 三段启动:
     *   阶段1 (0~8s): 基础PWM线性增加，姿态PID输出同步从0平滑增加到100%，积分清零
     *   阶段2 (8~9s): 基础PWM保持THROTTLE_TARGET，姿态PID已全量控制
     *   阶段3 (9s+):  基础PWM保持THROTTLE_TARGET，姿态PID持续控制 */
    if (auto_land_complete) {
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, (uint16_t)IMU_FS_STOP_PWM);
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, (uint16_t)IMU_FS_STOP_PWM);
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, (uint16_t)IMU_FS_STOP_PWM);
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, (uint16_t)IMU_FS_STOP_PWM);
        mixer.m1 = mixer.m2 = mixer.m3 = mixer.m4 = IMU_FS_STOP_PWM;
        elapsed_cycles = DWT->CYCCNT - control_start_cycles;
        control_last_cycles = elapsed_cycles;
        if (elapsed_cycles > control_max_cycles) control_max_cycles = elapsed_cycles;
        if (elapsed_cycles > (SystemCoreClock / 200U)) control_overrun++;
        return;
    }

    /* Keep receiver steps and PPM jitter from becoming instantaneous common
     * motor-speed changes. Lock/RC/IMU failsafes use separate direct paths. */
    float throttle_requested = throttle_target_cmd;
    if (throttle_requested < RAMP_START) throttle_requested = RAMP_START;
    if (throttle_requested > RC_FLIGHT_TEST_MAX_PWM) {
        throttle_requested = RC_FLIGHT_TEST_MAX_PWM;
    }
    {
    uint8_t airborne_for_throttle = tof_last_valid_ms != 0U &&
        (uint32_t)(HAL_GetTick() - tof_last_valid_ms) <= ALT_HOLD_STALE_MS &&
        flow_ground_height_valid &&
        tof_height_mm >= flow_ground_height_mm + ALT_HOLD_AIRBORNE_RISE_MM;
    float throttle_rise_step = airborne_for_throttle
                             ? RC_THROTTLE_AIR_RISE_STEP
                             : RC_THROTTLE_RISE_STEP;
    if (throttle_requested > throttle_slewed_cmd + throttle_rise_step) {
        throttle_slewed_cmd += throttle_rise_step;
    } else if (throttle_requested < throttle_slewed_cmd - RC_THROTTLE_FALL_STEP) {
        throttle_slewed_cmd -= RC_THROTTLE_FALL_STEP;
    } else {
        throttle_slewed_cmd = throttle_requested;
    }
    }

    uint8_t phase1 = (startup_tick < RAMP_TICKS);
    uint8_t phase2 = (startup_tick < RAMP_TICKS + STABILIZE_TICKS);
    float fade = 1.0f;  /* 正常飞行阶段始终保持全效PID */
    if (startup_tick < RAMP_TICKS + STABILIZE_TICKS) {
        startup_tick++;
    }
    if (phase1) 
			{
        mixer.throttle = RAMP_START + (THROTTLE_TARGET - RAMP_START)
                       * ((float)startup_tick / RAMP_TICKS);
        /* 飞机可能在斜坡中途离地；PID不能等到8秒后才接管。
         * 与油门同速渐入可在离地时已有相应修正，又不会突然加差速。 */
        fade = (float)startup_tick / RAMP_TICKS;
			} 
		else if (phase2)
			{
        mixer.throttle = THROTTLE_TARGET;
        fade = 1.0f;
			}
		else
			{
      /* Manual throttle mode: CH3 alone sets common motor PWM. */
      mixer.throttle = throttle_slewed_cmd;
        if (mixer.throttle < RAMP_START) mixer.throttle = RAMP_START;
        if (mixer.throttle > MOTOR_MAX)  mixer.throttle = MOTOR_MAX;
    }
    /* phase3: throttle 保持 THROTTLE_TARGET, fade 保持 1.0 */
    throttle_base_debug = (uint16_t)mixer.throttle;
    startup_phase_debug = phase1 ? 1U : (phase2 ? 2U : 3U);

    /* Reference-controller idle state: after arming, raise all four motors
     * together from stop to 1100us. Once complete, keep 1100us as the armed
     * floor even while receiver throttle remains at its 1000us endpoint. */
    if (motor_idle_ramp_active) {
        if (motor_idle_ramp_pwm < MOTOR_MIN) {
            motor_idle_ramp_pwm += MOTOR_IDLE_RAMP_STEP;
            if (motor_idle_ramp_pwm > MOTOR_MIN) motor_idle_ramp_pwm = MOTOR_MIN;
            mixer.throttle = motor_idle_ramp_pwm;
        } else {
            motor_idle_ramp_active = 0U;
            mixer.throttle = throttle_slewed_cmd;
        }
    }
    if (!auto_land_active) {
        AltHold_Update(throttle_slewed_cmd, motor_idle_ramp_active);
    } else if (alt_hold_enabled) {
        alt_hold_enabled = 0U;
        PID_Reset(&pid_height);
    }
    AutoLand_Update();

    /* Official MaplePilot takeoff rule: below THR_CONTROL_WORK, mix throttle
     * only and clear every attitude integrator.  At/above 1100us, enable the
     * complete attitude controller immediately.  Laser height is not used to
     * decide whether attitude control is allowed to work. */
    fade = (!motor_idle_ramp_active && mixer.throttle >= RC_CONTROL_WORK_PWM)
         ? 1.0f : 0.0f;
    throttle_base_debug = (uint16_t)mixer.throttle;
    startup_phase_debug = motor_idle_ramp_active ? 1U
                        : ((THROTTLE_TARGET < RC_CONTROL_WORK_PWM) ? 2U : 3U);

    BMI088_Data_t latest_imu_sample;
    uint32_t latest_imu_ms;
    uint32_t imu_snapshot_primask = __get_PRIMASK();
    __disable_irq();
    latest_imu_sample = imu_latest_raw;
    latest_imu_ms = imu_latest_ms;
    if (imu_snapshot_primask == 0U) __enable_irq();

    if (!imu_failsafe_active &&
        (uint32_t)(HAL_GetTick() - latest_imu_ms) <= IMU_STALE_LIMIT_MS)
    {
        imu = latest_imu_sample;
        imu_ok++;
        imu_consecutive_fail = 0U;
        imu.gx -= gx_off;
        imu.gy -= gy_off;
        imu.gz -= gz_off;

        /* 与官方sensor_raw_update一致，在姿态融合和PID之前过滤IMU。 */
        imu.ax = butterworth(imu.ax, &accel_lpf_buf[0], &accel_lpf_param);
        imu.ay = butterworth(imu.ay, &accel_lpf_buf[1], &accel_lpf_param);
        imu.az = butterworth(imu.az, &accel_lpf_buf[2], &accel_lpf_param);
        imu.gx = butterworth(imu.gx, &gyro_lpf_buf[0], &gyro_lpf_param);
        imu.gy = butterworth(imu.gy, &gyro_lpf_buf[1], &gyro_lpf_param);
        imu.gz = butterworth(imu.gz, &gyro_lpf_buf[2], &gyro_lpf_param);
        if (FastAbs(imu.gz) < GYRO_Z_DEADBAND_DPS) imu.gz = 0.0f;

        /* Official optical-flow axis relationship, expressed in this
         * airframe's +X/+Y translation coordinates.  These 6 Hz values are
         * sampled by the 50 Hz flow update to remove camera rotation. */
        flow_gyro_x_rad_s += FLOW_GYRO_LPF_ALPHA *
            (imu.gy * DEG_TO_RAD_F - flow_gyro_x_rad_s);
        flow_gyro_y_rad_s += FLOW_GYRO_LPF_ALPHA *
            (imu.gx * DEG_TO_RAD_F - flow_gyro_y_rad_s);

        float pitch_acc = atan2f(imu.ay, sqrtf(imu.ax*imu.ax + imu.az*imu.az)) * 57.2958f;
        float roll_acc  = atan2f(imu.ax, sqrtf(imu.ay*imu.ay + imu.az*imu.az)) * 57.2958f;
        /* 互补滤波始终运行, 保持姿态估计连续 */
        pitch = ATTITUDE_ALPHA * (pitch + imu.gx * CONTROL_DT)
              + (1.0f - ATTITUDE_ALPHA) * pitch_acc;
        roll  = ATTITUDE_ALPHA * (roll - imu.gy * CONTROL_DT)
              + (1.0f - ATTITUDE_ALPHA) * roll_acc;
        yaw  += imu.gz * CONTROL_DT;
        if (yaw > 180.0f) yaw -= 360.0f;
        if (yaw < -180.0f) yaw += 360.0f;

        /* PID始终计算(预热), 输出量由fade控制 */
        /* 官方级联PID: 外环(角度P) → 内环(角速度PID+巴特沃斯D项) */
        static uint32_t takeoff_guard_start_ms = 0U;
        uint32_t attitude_now = HAL_GetTick();
        uint8_t takeoff_height_fresh = tof_last_valid_ms != 0U &&
            (uint32_t)(attitude_now - tof_last_valid_ms) <= ALT_HOLD_STALE_MS;
        float takeoff_rise_mm = (takeoff_height_fresh && flow_ground_height_valid)
                              ? tof_height_mm - flow_ground_height_mm : 0.0f;
        uint8_t takeoff_guard_active = takeoff_height_fresh &&
            flow_ground_height_valid &&
            mixer.throttle >= TAKEOFF_GUARD_MIN_PWM &&
            takeoff_rise_mm >= TAKEOFF_GUARD_MIN_RISE_MM &&
            takeoff_rise_mm < TAKEOFF_GUARD_MAX_RISE_MM;
        takeoff_guard_active_debug = takeoff_guard_active;
        if (takeoff_guard_active) {
            if (takeoff_guard_start_ms == 0U)
                takeoff_guard_start_ms = attitude_now;
        } else {
            takeoff_guard_start_ms = 0U;
        }

        float pitch_control_target = constrain_float(
            level_pitch_ref_deg + (auto_land_active ? 0.0f : pitch_target_cmd) +
            flow_pitch_correction_deg,
            level_pitch_ref_deg - 8.0f, level_pitch_ref_deg + 8.0f);
        float roll_control_target = constrain_float(
            level_roll_ref_deg + (auto_land_active ? 0.0f : roll_target_cmd) +
            flow_roll_correction_deg,
            level_roll_ref_deg - 8.0f, level_roll_ref_deg + 8.0f);
        /* No fixed take-off angle bias is added.  The physically measured
         * frame-level reference defines zero; the guard below only increases
         * feedback authority when a real lift-off attitude error is present. */
        /* A large tilt just after lift-off gets all available authority for
         * levelling; pilot/position commands resume as soon as it recovers. */
        if (takeoff_guard_active &&
            (FastAbs(pitch - level_pitch_ref_deg) >= TAKEOFF_GUARD_RECOVERY_DEG ||
             FastAbs(roll - level_roll_ref_deg) >= TAKEOFF_GUARD_RECOVERY_DEG)) {
            pitch_control_target = level_pitch_ref_deg;
            roll_control_target = level_roll_ref_deg;
        }
        uint8_t takeoff_boost_active = takeoff_guard_active &&
            (FastAbs(pitch_control_target - pitch) >= TAKEOFF_GUARD_ERROR_DEG ||
             FastAbs(roll_control_target - roll) >= TAKEOFF_GUARD_ERROR_DEG);
        float pitch_outer_kp = pid_pitch.kp;
        float roll_outer_kp = pid_roll.kp;
        if (takeoff_boost_active) {
            pid_pitch.kp = pitch_outer_kp * TAKEOFF_GUARD_ANGLE_P_SCALE;
            pid_roll.kp = roll_outer_kp * TAKEOFF_GUARD_ANGLE_P_SCALE;
        }
        float pitch_desired_rate = Attitude_Update_Outer(&pid_pitch, pitch_control_target,
                                                         pitch, CONTROL_DT);
        float roll_desired_rate  = Attitude_Update_Outer(&pid_roll, roll_control_target,
                                                         roll, CONTROL_DT);
        pid_pitch.kp = pitch_outer_kp;
        pid_roll.kp = roll_outer_kp;
        float pitch_i_before = pid_pitch_rate.integrate;
        float roll_i_before = pid_roll_rate.integrate;
        float yaw_i_before = pid_yaw_rate.integrate;
        /* Match the reference controller: the physical output may already be
         * held at idle, but attitude control follows the receiver throttle.
         * Therefore low stick means equal idle motors and cleared I terms. */
        /* Keep the reference controller's full P/D authority from idle, but
         * adapt its I enabling point to this airframe's measured lift region.
         * The roll cage constrains the frame below about 1450us; integrating
         * there stores a large false correction and releases it at lift-off. */
        attitude_integral_scale = (mixer.throttle - RC_INTEGRAL_START_PWM) /
                                  (RC_INTEGRAL_FULL_PWM - RC_INTEGRAL_START_PWM);
        attitude_integral_scale = constrain_float(attitude_integral_scale, 0.0f, 1.0f);
        if (takeoff_guard_active && takeoff_guard_start_ms != 0U) {
            float guard_i_ramp = (float)(uint32_t)(attitude_now - takeoff_guard_start_ms) /
                                 (float)TAKEOFF_GUARD_I_RAMP_MS;
            float guard_i_scale = 0.5f + 0.5f * constrain_float(guard_i_ramp, 0.0f, 1.0f);
            if (attitude_integral_scale < guard_i_scale)
                attitude_integral_scale = guard_i_scale;
        }
        if (motor_idle_ramp_active) attitude_integral_scale = 0.0f;
        uint8_t integral_hold = (attitude_integral_scale <= 0.0f);
        uint8_t attitude_output_enabled = !motor_idle_ramp_active &&
                                          (mixer.throttle >= RC_CONTROL_WORK_PWM);
        attitude_fade_debug = attitude_output_enabled ? fade : 0.0f;
        float mixer_lower_limit = (mixer.throttle < MOTOR_MIN) ? RAMP_START : MOTOR_MIN;
        float motor_trim_blend = (mixer.throttle - RC_CONTROL_WORK_PWM) /
                                 (MOTOR_TRIM_FULL_PWM - RC_CONTROL_WORK_PWM);
        motor_trim_blend = constrain_float(motor_trim_blend, 0.0f, 1.0f);
        if (!attitude_output_enabled) motor_trim_blend = 0.0f;
        motor_trim_blend_debug = motor_trim_blend;
        /* Mixer signs: negative pitch raises LF+RF (front), while negative
         * roll raises RF+RR (right).  Their sum gives the largest help to M2. */
        float pitch_weight_trim = -MOTOR_TRIM_FRONT_PWM * motor_trim_blend;
        float roll_weight_trim  = -MOTOR_TRIM_RIGHT_PWM * motor_trim_blend;

        /* 官方在油门尚未进入有效控制区时持续清姿态积分。
         * 斜坡阶段只使用立即响应的P/D，避免机体尚未起转时I项先攒满。 */
        if (integral_hold) {
            pid_pitch_rate.integrate = 0.0f;
            pid_roll_rate.integrate = 0.0f;
            pid_yaw_rate.integrate = 0.0f;
        }
        /* High-throttle gain scheduling.  Work from the current base gains so
         * future parameter changes remain valid, then restore them immediately. */
        float schedule = (mixer.throttle - RATE_SCHED_START_PWM) /
                         (RATE_SCHED_END_PWM - RATE_SCHED_START_PWM);
        schedule = constrain_float(schedule, 0.0f, 1.0f);
        float rate_p_scale = 1.0f - (1.0f - RATE_P_HIGH_SCALE) * schedule;
        float rate_d_scale = 1.0f - (1.0f - RATE_D_HIGH_SCALE) * schedule;
        if (takeoff_boost_active)
            rate_p_scale *= TAKEOFF_GUARD_RATE_P_SCALE;
        float pitch_kp_base = pid_pitch_rate.kp;
        float pitch_ki_base = pid_pitch_rate.ki;
        float pitch_kd_base = pid_pitch_rate.kd;
        float roll_kp_base = pid_roll_rate.kp;
        float roll_ki_base = pid_roll_rate.ki;
        float roll_kd_base = pid_roll_rate.kd;
        pid_pitch_rate.kp = pitch_kp_base * rate_p_scale;
        pid_pitch_rate.ki = pitch_ki_base * attitude_integral_scale;
        pid_pitch_rate.kd = pitch_kd_base * rate_d_scale;
        pid_roll_rate.kp = roll_kp_base * rate_p_scale;
        pid_roll_rate.ki = roll_ki_base * attitude_integral_scale;
        pid_roll_rate.kd = roll_kd_base * rate_d_scale;

        /* Gyro-Z heading hold.  A deliberate yaw-stick command keeps direct
         * rate control and moves the heading reference with the aircraft.
         * On stick release the new heading is captured and held.  Below the
         * attitude-control threshold we continuously follow the measured yaw,
         * so no heading error can accumulate while the aircraft is on ground. */
        float yaw_rate_control_target;
        if (!attitude_output_enabled) {
            yaw_heading_target_deg = yaw;
            yaw_rate_control_target = 0.0f;
        } else if (!auto_land_active && FastAbs(yaw_rate_target_cmd) > 1.0f) {
            yaw_heading_target_deg = yaw;
            yaw_rate_control_target = yaw_rate_target_cmd;
        } else {
            float yaw_error = yaw_heading_target_deg - yaw;
            if (yaw_error > 180.0f) yaw_error -= 360.0f;
            if (yaw_error < -180.0f) yaw_error += 360.0f;
            yaw_rate_control_target = constrain_float(YAW_HOLD_KP * yaw_error,
                                                       -YAW_HOLD_RATE_LIMIT,
                                                       YAW_HOLD_RATE_LIMIT);
        }
        yaw_hold_rate_debug = yaw_rate_control_target;
        float po = PID_Update_Inner(&pid_pitch_rate, pitch_desired_rate, imu.gx,  CONTROL_DT);
        float ro = PID_Update_Inner(&pid_roll_rate,  roll_desired_rate,  -imu.gy, CONTROL_DT);
        float yo = PID_Update_Inner(&pid_yaw_rate, yaw_rate_control_target, imu.gz, CONTROL_DT);
        pid_pitch_rate.kp = pitch_kp_base;
        pid_pitch_rate.ki = pitch_ki_base;
        pid_pitch_rate.kd = pitch_kd_base;
        pid_roll_rate.kp = roll_kp_base;
        pid_roll_rate.ki = roll_ki_base;
        pid_roll_rate.kd = roll_kd_base;
        if (integral_hold) {
            pid_pitch_rate.integrate = 0.0f;
            pid_roll_rate.integrate = 0.0f;
            pid_yaw_rate.integrate = 0.0f;
        }

        /* pitch_out不取反(与2807一致), roll_out不取反(内环-gy已自带取反) */
        /* Below MOTOR_MIN the four motors are crossing their individual start
         * thresholds.  Applying P/D differential here can stop one motor and
         * restart it on the next correction, which looks like twitching.
         * Keep all four outputs equal during this linear spin-up region and
         * hand attitude control over only after stable idle is reached. */
        if (!attitude_output_enabled) {
            mixer.pitch_out = 0.0f;
            mixer.roll_out  = 0.0f;
            mixer.yaw_out   = 0.0f;
        } else {
            mixer.pitch_out = po * fade + pitch_weight_trim;
            mixer.roll_out  = ro * fade + roll_weight_trim;
            mixer.yaw_out   = yo * fade * YAW_CONTROL_SIGN;
        }

        /* PID自身尚未到输出上限时，四电机混控也可能先碰到1150/2000。
         * 饱和时撤销本周期中让积分绝对值继续增大的部分；反向卸载仍保留。 */
        mixer_saturated = Mixer_Would_Saturate(&mixer, mixer_lower_limit);
        if (mixer_saturated) {
            if (FastAbs(pid_pitch_rate.integrate) > FastAbs(pitch_i_before)) {
                po += pitch_i_before - pid_pitch_rate.integrate;
                pid_pitch_rate.integrate = pitch_i_before;
                pid_pitch_rate.control_output = constrain_float(
                    po, -pid_pitch_rate.control_output_limit,
                    pid_pitch_rate.control_output_limit);
            }
            if (FastAbs(pid_roll_rate.integrate) > FastAbs(roll_i_before)) {
                ro += roll_i_before - pid_roll_rate.integrate;
                pid_roll_rate.integrate = roll_i_before;
                pid_roll_rate.control_output = constrain_float(
                    ro, -pid_roll_rate.control_output_limit,
                    pid_roll_rate.control_output_limit);
            }
            if (FastAbs(pid_yaw_rate.integrate) > FastAbs(yaw_i_before)) {
                yo += yaw_i_before - pid_yaw_rate.integrate;
                pid_yaw_rate.integrate = yaw_i_before;
                pid_yaw_rate.control_output = constrain_float(
                    yo, -pid_yaw_rate.control_output_limit,
                    pid_yaw_rate.control_output_limit);
            }
            if (!attitude_output_enabled) {
                mixer.pitch_out = 0.0f;
                mixer.roll_out  = 0.0f;
            } else {
                mixer.pitch_out = po * fade + pitch_weight_trim;
                mixer.roll_out  = ro * fade + roll_weight_trim;
                mixer.yaw_out   = yo * fade * YAW_CONTROL_SIGN;
            }
        }
        /* Preserve roll/pitch differential by shifting all motors together
         * before scaling. Independent clipping loses correction authority. */
        Mixer_Update_Limited(&mixer, mixer_lower_limit);
        if (debug_mode) {
            /* 调试模式: 电机全停, 只看传感器数据 */
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 990);
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 990);
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 990);
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 990);
        } else if (motor_idle_ramp_active) {
            Startup_Mixer_Output(&mixer);
        } else {
            Mixer_Output(&mixer);
        }
    }
    else
    {
        imu_fail++;
        if (!imu_failsafe_active) {
            if (imu_consecutive_fail < 0xFFU) {
                imu_consecutive_fail++;
            }
            if (imu_consecutive_fail >= IMU_FAIL_LIMIT) {
                /* 清除I项，撤销失效前可能残留的姿态差速。 */
                pid_pitch_rate.integrate = 0.0f;
                pid_roll_rate.integrate = 0.0f;
                pid_yaw_rate.integrate = 0.0f;
                imu_failsafe_pwm = (mixer.m1 + mixer.m2 + mixer.m3 + mixer.m4) * 0.25f;
                if (imu_failsafe_pwm < IMU_FS_STOP_PWM) {
                    imu_failsafe_pwm = IMU_FS_STOP_PWM;
                }
                if (imu_failsafe_pwm > MOTOR_MAX) {
                    imu_failsafe_pwm = MOTOR_MAX;
                }
                imu_failsafe_active = 1U;
            }
        }
        if (imu_failsafe_active) {
            IMU_Failsafe_Output();
        }
    }

    elapsed_cycles = DWT->CYCCNT - control_start_cycles;
    control_last_cycles = elapsed_cycles;
    if (elapsed_cycles > control_max_cycles) {
        control_max_cycles = elapsed_cycles;
    }
    if (elapsed_cycles > (SystemCoreClock / 200U)) {
        control_overrun++;
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
